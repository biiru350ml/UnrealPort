// Fill out your copyright notice in the Description page of Project Settings.


#include "Items/InteractableItem.h"
#include"Saves/MySaveGame.h"
#include "Blueprint/UserWidget.h"
#include"Kismet/GameplayStatics.h"

AInteractableItem::AInteractableItem()
{
	PrimaryActorTick.bCanEverTick = true;

	MyRootComponent = CreateDefaultSubobject<USceneComponent>(TEXT("RootComponent"));
	RootComponent = MyRootComponent;

	MyMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("Mesh"));
	MyMesh->SetupAttachment(RootComponent);

	InteractionWidget = CreateDefaultSubobject<UWidgetComponent>(TEXT("InteractionWidget"));
	InteractionWidget->SetupAttachment(RootComponent);
}

void AInteractableItem::BeginPlay()
{
	Super::BeginPlay();
	HideInteractionWidget();

}

void AInteractableItem::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

void AInteractableItem::ShowText()
{
	TextWidget = CreateWidget<UUserWidget>(GetWorld(), TextWidgetClass);
	if (TextWidget)
	{
		TextWidget->AddToViewport();
	}
}
void AInteractableItem::HideText()
{
	if (TextWidget)
	{
		TextWidget->RemoveFromParent();
	}
}

void AInteractableItem::ShowInteractionWidget()
{
	InteractionWidget->SetVisibility(true);
}

void AInteractableItem::HideInteractionWidget()
{
	InteractionWidget->SetVisibility(false);
}


EInteractType AInteractableItem::GetInteractType()
{
	return InteractType;
}

