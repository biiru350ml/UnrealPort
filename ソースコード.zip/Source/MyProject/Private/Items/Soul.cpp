// Fill out your copyright notice in the Description page of Project Settings.


#include "Items/Soul.h"
#include"Interfaces/PickUpInterface.h"
#include"Kismet/GameplayStatics.h"
#include"Saves/MySaveGame.h"


void ASoul::OnSphereOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
	IPickUpInterface* PickUpInterface = Cast<IPickUpInterface>(OtherActor);
	if (PickUpInterface)
	{
		if (SoulAmount != 0)
		{
			PickUpInterface->AddSouls(this);
		}
		if (HealAmount != 0)
		{
			PickUpInterface->HealBySoul(this);
		}
		if (IncreaseMaxHealthAmount != 0)
		{
			PickUpInterface->IncreaseMaxHealthBySoul(this);
			PickUpInterface->AddObtainedRedSoul(this);
			bObtained = true;

		}
		if (IncreaseMaxStaminaAmount != 0)
		{
			PickUpInterface->IncreaseMaxStaminaBySoul(this);
			PickUpInterface->AddObtainedGreenSoul(this);
			bObtained = true;

		}
		SpawnPickupSystem();
		SpawnPickupSound();
		SetActorHiddenInGame(true);
		SetActorEnableCollision(false);
		SetActorTickEnabled(false);
	}


}
