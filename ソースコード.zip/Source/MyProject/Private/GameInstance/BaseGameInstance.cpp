// Fill out your copyright notice in the Description page of Project Settings.


#include "GameInstance/BaseGameInstance.h"

UBaseGameInstance::UBaseGameInstance()
{
	MusicType = EMusicType::EMT_None;
	MusicRef = nullptr;
}
