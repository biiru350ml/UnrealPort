// Fill out your copyright notice in the Description page of Project Settings.


#include "Saves/MySaveGame.h"

void UMySaveGame::SetObtainedSouls(const TArray<ASoul*>& obtainedSouls)
{
	ObtainedSouls = obtainedSouls;
}
