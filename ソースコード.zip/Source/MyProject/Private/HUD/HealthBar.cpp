// Fill out your copyright notice in the Description page of Project Settings.


#include "HUD/HealthBar.h"
#include "Components/ProgressBar.h"
#include "Components/TextBlock.h"

void UHealthBar::NativeTick(const FGeometry& MyGeometry, float DeltaTime)
{
	Super::NativeTick(MyGeometry, DeltaTime);

	if (BottomHealthBar && TopHealthBar)
	{
		float CurrentPercent = BottomHealthBar->GetPercent();
		float TargetPercent = TopHealthBar->GetPercent();

		CurrentPercent = FMath::FInterpTo(CurrentPercent, TargetPercent, DeltaTime, HealthBarUpdateSpeed);

		BottomHealthBar->SetPercent(CurrentPercent);
	}
}

void UHealthBar::SetBossHealthBarPercent(float Percent)
{
	if (TopHealthBar)
	{
		TopHealthBar->SetPercent(Percent);
	}
}

void UHealthBar::SetBossName(FString bossName)
{
	if (BossName)
	{
		BossName->SetText(FText::FromString(bossName));
	}
}
