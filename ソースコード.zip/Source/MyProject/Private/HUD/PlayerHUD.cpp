// Fill out your copyright notice in the Description page of Project Settings.


#include "HUD/PlayerHUD.h"
#include"HUD/PlayerOverlay.h"
#include "HUD/HealthBar.h"

void APlayerHUD::ShowBossHealthBar()
{
	BossHealthBar->AddToViewport();
}

void APlayerHUD::HideBossHealthBar()
{
	if (BossHealthBar)
	{
		BossHealthBar->RemoveFromParent();
	}
}

void APlayerHUD::ShowPlayerOverlay()
{
	PlayerOverlay->AddToViewport();
}

void APlayerHUD::BeginPlay()
{
	Super::BeginPlay();
	UWorld* World = GetWorld();

	if (World)
	{
		APlayerController* Controller = World->GetFirstPlayerController();
		if (Controller && PlayerOverlayClass && BossHealthBarClass)
		{
			PlayerOverlay = CreateWidget<UPlayerOverlay>(Controller, PlayerOverlayClass);
			BossHealthBar = CreateWidget<UHealthBar>(Controller, BossHealthBarClass);
		}
	}
}
