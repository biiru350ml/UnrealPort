// Fill out your copyright notice in the Description page of Project Settings.


#include "HUD/PlayerOverlay.h"
#include"Components/ProgressBar.h"
#include"Components/TextBlock.h"
#include "Components/CanvasPanelSlot.h"

void UPlayerOverlay::SetHealthBarPercent(float Percent)
{
	if (HealthBar)
	{
		HealthBar->SetPercent(Percent);
	}
}

void UPlayerOverlay::NativeTick(const FGeometry& MyGeometry, float DeltaTime)
{
	Super::NativeTick(MyGeometry, DeltaTime);

	if (BottomStaminaBar && TopStaminaBar)
	{
		float CurrentPercent = BottomStaminaBar->GetPercent();
		float NewPercent = TopStaminaBar->GetPercent();

		//Top�̃X�^�~�i��Bottom��葽���ꍇ�ATop�Ɠ����悤�ɂ���
		if (NewPercent > CurrentPercent)
		{
			BottomStaminaBar->SetPercent(NewPercent);
			TargetStamina = NewPercent;
		}
		else
		{
			//Bottom�̃X�^�~�i��Top��葽���ꍇ�ATop�ɋ߂Â�
			if (NewPercent < TargetStamina)
			{
				TargetStamina = NewPercent;
			}
			CurrentPercent = FMath::FInterpTo(CurrentPercent, TargetStamina, DeltaTime, StaminaBarUpdateSpeed);
			BottomStaminaBar->SetPercent(CurrentPercent);
		}
	}
}

void UPlayerOverlay::SetStaminaBarPercent(float Percent)
{
	if (TopStaminaBar)
	{
		TopStaminaBar->SetPercent(Percent);
	}
}

void UPlayerOverlay::SetHitBarPercent(float Percent)
{
	if (HitBar)
	{
		HitBar->SetPercent(Percent);
	}
}

void UPlayerOverlay::SetGold(int32 Gold)
{
	
	if (GoldCount)
	{
		const FString GoldString = FString::Printf(TEXT("%d"), Gold);
		const FText GoldText = FText::FromString(GoldString);
		GoldCount->SetText(GoldText);
	}
}

void UPlayerOverlay::SetSoul(int32 Soul)
{
	if (SoulCount)
	{
		const FString SoulString = FString::Printf(TEXT("%d"), Soul);
		const FText SoulText = FText::FromString(SoulString);
		SoulCount->SetText(SoulText);
	}
}

void UPlayerOverlay::SetRedSoulNum(int32 redSoulNum)
{
	if (RedSoulNum)
	{
		const FString SoulString = FString::Printf(TEXT("%d"), redSoulNum);
		const FText SoulText = FText::FromString(SoulString);
		RedSoulNum->SetText(SoulText);
	}
}

void UPlayerOverlay::SetGreenSoulNum(int32 greenSoulNum)
{
	if (GreenSoulNum)
	{
		const FString SoulString = FString::Printf(TEXT("%d"), greenSoulNum);
		const FText SoulText = FText::FromString(SoulString);
		GreenSoulNum->SetText(SoulText);
	}
}

void UPlayerOverlay::UpdateHealthBar(float CurrentMaxHealth, float MaxHealth)
{
	if (HealthBar)
	{
		// �V���������l�o�[�̒������v�Z
		UCanvasPanelSlot* HealthBarSlot = Cast<UCanvasPanelSlot>(HealthBar->Slot);
		float CurrentHealthBarLength = 0.f;
		if (HealthBarSlot)
		{
			CurrentHealthBarLength = HealthBarSlot->GetSize().X;
			CurrentHealthBarLength *= (CurrentMaxHealth / MaxHealth);

			// �����l�o�[�̃T�C�Y���A�b�v�f�[�g

			FAnchors Anchors;
			Anchors.Minimum = FVector2D(0.0f, 0.0f);
			Anchors.Maximum = FVector2D(0.0f, 0.0f);
			HealthBarSlot->SetAnchors(Anchors);

			FVector2D Size;
			Size.X = CurrentHealthBarLength;
			Size.Y = HealthBarSlot->GetSize().Y;
			HealthBarSlot->SetSize(Size);

		}
	}
}

void UPlayerOverlay::UpdateStaminaBar(float CurrentMaxStamina, float MaxStamina)
{
	if (TopStaminaBar && BottomStaminaBar)
	{
		UCanvasPanelSlot* TopStaminaBarSlot = Cast<UCanvasPanelSlot>(TopStaminaBar->Slot);
		UCanvasPanelSlot* BottomStaminaBarSlot = Cast<UCanvasPanelSlot>(BottomStaminaBar->Slot);
		float CurrentTopStaminaBarLength = 0.f;
		float CurrentBottomStaminaBarLength = 0.f;
		if (TopStaminaBarSlot && BottomStaminaBar)
		{
			CurrentTopStaminaBarLength = TopStaminaBarSlot->GetSize().X;
			CurrentBottomStaminaBarLength = BottomStaminaBarSlot->GetSize().X;


			CurrentTopStaminaBarLength *= (CurrentMaxStamina / MaxStamina);
			CurrentBottomStaminaBarLength *= (CurrentMaxStamina / MaxStamina);
		

			FAnchors Anchors;
			Anchors.Minimum = FVector2D(0.0f, 0.0f);
			Anchors.Maximum = FVector2D(0.0f, 0.0f);
			TopStaminaBarSlot->SetAnchors(Anchors);
			BottomStaminaBarSlot->SetAnchors(Anchors);

			FVector2D Size;
			Size.X = CurrentTopStaminaBarLength;
			Size.Y = TopStaminaBarSlot->GetSize().Y;
			TopStaminaBarSlot->SetSize(Size);
			Size.Y = BottomStaminaBarSlot->GetSize().Y;
			BottomStaminaBarSlot->SetSize(Size);
		}
	}
}


