// Fill out your copyright notice in the Description page of Project Settings.


#include "Interfaces/PickUpInterface.h"

// Add default functionality here for any IPickUpInterface functions that are not pure virtual.

void IPickUpInterface::SetOverlappingItem(AItem* Item)
{
}

void IPickUpInterface::AddSouls(ASoul* Soul)
{
}

void IPickUpInterface::HealBySoul(ASoul* Soul)
{
}

void IPickUpInterface::IncreaseMaxHealthBySoul(ASoul* Soul)
{
}

void IPickUpInterface::IncreaseMaxStaminaBySoul(ASoul* Soul)
{
}

void IPickUpInterface::AddGold(ATreasure* Treasure)
{
}

void IPickUpInterface::AddObtainedRedSoul(ASoul* ObtainedSouls)
{
}

void IPickUpInterface::AddObtainedGreenSoul(ASoul* ObtainedSouls)
{
}
