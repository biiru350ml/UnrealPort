// Fill out your copyright notice in the Description page of Project Settings.


#include "Enemy/BossEnemy.h"
#include"AIController.h"
#include"Components/AttributeComponent.h"
#include"HUD/HealthBarComponent.h"
#include"Components/CapsuleComponent.h"
#include"GameFramework/CharacterMovementComponent.h"
#include"Components/BoxComponent.h"
#include"HUD/PlayerHUD.h"
#include "HUD/HealthBar.h"
#include"Components/SceneComponent.h"
#include"Perception/PawnSensingComponent.h"
#include"Kismet/KismetSystemLibrary.h"
#include"Kismet/GameplayStatics.h"


ABossEnemy::ABossEnemy()
{
	WeaponHitBox2 = CreateDefaultSubobject<UBoxComponent>(TEXT("WeaponHitBox2"));
	WeaponHitBox2->SetupAttachment((GetRootComponent()));

	TraceStart2 = CreateDefaultSubobject<USceneComponent>(TEXT("TraceStart2"));
	TraceStart2->SetupAttachment(GetRootComponent());

	TraceEnd2 = CreateDefaultSubobject<USceneComponent>(TEXT("TraceEnd2"));
	TraceEnd2->SetupAttachment(GetRootComponent());

}

void ABossEnemy::Tick(float DeltaTime)
{
	if (IsEngaged())
	{
		return;
	}
	if (OutAttackRadius() && IsAlive() && CombatTarget)
	{
		//�������U��
		RangedAttack();
		if (OutAttackRadius())
		{
			//�U�����N�[�����O���ł���Βǐ�
			ChaseTarget();
		}
	}
	else if (InAttackRadius() && EnemyState != EEnemyState::EES_Enagaged && IsAlive())
	{
		//�ߋ����U��
		Attack();
	}
}

void ABossEnemy::BeginPlay()
{
	Super::BeginPlay();

	if (WeaponHitBox && WeaponHitBox2)
	{
		WeaponHitBox->OnComponentBeginOverlap.RemoveDynamic(this, &AEnemy::OnBoxOverlap);
		WeaponHitBox->OnComponentBeginOverlap.AddDynamic(this, &ABossEnemy::OnBoxOverlap);
		WeaponHitBox2->OnComponentBeginOverlap.AddDynamic(this, &ABossEnemy::OnBoxOverlap);
	}

	if (PawnSensing)
	{
		PawnSensing->OnSeePawn.RemoveDynamic(this, &AEnemy::PawnSeen);
		PawnSensing->OnSeePawn.AddDynamic(this, &ABossEnemy::PawnSeen);
	}
	CurrentDefence = DefaultDefence;
}

void ABossEnemy::Attack()
{
	if (CombatTarget && CombatTarget->ActorHasTag(FName("Dead")))
	{
		CombatTarget = nullptr;
		return;
	}
	if (IsPlayingHitReactAnimation() || EnemyState == EEnemyState::EES_Enagaged)return;
	EnemyState = EEnemyState::EES_Attacking;
	PlayAttackMontage();

}

void ABossEnemy::RangedAttack()
{
	if (CombatTarget && CombatTarget->ActorHasTag(FName("Dead")))
	{
		CombatTarget = nullptr;
		return;
	}
	CoolAttackLogic(RangedAttackName);

}

void ABossEnemy::PlayAttackMontage()
{
	CoolAttackLogic(AttackMontageSelections);
}

void ABossEnemy::GetHit_Implementation(const FVector& ImpactPoint, AActor* Hitter)
{
	if (Attributes && Attributes->IsAlive() && Hitter)
	{
		if (CurrentDamageThreshold <= 0)
		{
			CurrentDefence = HitterDamage * DefenceFactor;
			EnemyState = EEnemyState::EES_Enagaged;
			PlayHitReactMontage("Default");
			DisableWeaponCollsion();
			StopMontage(AttackMontage);
			CurrentDamageThreshold = DefaultDamageThreshold;
		}
	}

	else
	{
		Die();
	}

	PlayHitSound(ImpactPoint);
	PlayHitParticles(ImpactPoint);
}

float ABossEnemy::TakeDamage(float DamageAmount, FDamageEvent const& DamageEvent, AController* EventInstigator, AActor* DamageCauser)
{
	if (Attributes && BossHealthBar)
	{
		//�f�[�^����
		Attributes->ReceiveDamage(DamageAmount - CurrentDefence);
		if (CurrentDamageThreshold > 0)
		{
			CurrentDamageThreshold -= DamageAmount - CurrentDefence;
		}
		//HUD�\���X�V
		BossHealthBar->SetBossHealthBarPercent(Attributes->GetHealthPercent());

		if (HitterDamage != DamageAmount)
		{
			HitterDamage = DamageAmount;
		}
		if (Attributes->GetHealthPercent() < StageTwoHealthLine && BossState == EBossState::EBS_Normal)
		{
			BossState = EBossState::EBS_StageTwo;
			StageChange(StageChangeTwoMontage, StageTwoAttackCoolDownRate, StageTwoAttackSpeedRate, StageTwoChasingSpeedRate, StageTwoAttackName);

		}

	}

	CombatTarget = EventInstigator->GetPawn();

	if (!IsEngaged())
	{
		ChaseTarget();
	}

	return DamageAmount - CurrentDefence;
}

void ABossEnemy::StageChange(UAnimMontage* stageChangeMontage, float stageAttackCollDownRate, float stageAttackSpeedRate, float stageChasingSpeedRate, TArray< FName> newAttackName)
{
	EnemyState = EEnemyState::EES_Enagaged;
	CurrentDefence = HitterDamage * DefenceFactor;
	UAnimInstance* AnimInstance = GetMesh()->GetAnimInstance();
	if (AnimInstance)
	{
		if (IsPlayingAttackAnimation())
		{
			AnimInstance->Montage_Stop(0.f, AttackMontage);
		}
		AnimInstance->Montage_Play(stageChangeMontage);
	}

	for (auto Element : AttackCooldownTime)
	{
		Element.Value *= stageAttackCollDownRate;//�X�L���N�[���_�E�����ԒZ�k
	}

	AttackMontage->RateScale *= stageAttackSpeedRate;//�A�^�b�N�����ω�
	CurrentAttackRateScale = AttackMontage->RateScale;
	ChangeChasingSpeed(stageChasingSpeedRate);//�ǐՑ��x�ω�

	//�V�����X�L����ǉ�
	AttackMontageSelections.Append(newAttackName);
}

void ABossEnemy::OnBoxOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
	if (ActorIsSameType(OtherActor)) return;

	FHitResult BoxHit;
	FVector CollisionBoxExtent = WeaponHitBox->Bounds.BoxExtent;
	BoxHit = PerformWeaponTrace(TraceStart, TraceEnd, WeaponHitBox, CollisionBoxExtent);

	FVector CollisionBoxExtent2 = WeaponHitBox2->Bounds.BoxExtent;
	FHitResult BoxHit2;

	BoxHit2 = PerformWeaponTrace(TraceStart2, TraceEnd2, WeaponHitBox2, CollisionBoxExtent2);

	bool retflag;
	ProcessDamage(BoxHit, WeaponHitBox, retflag);
	ProcessDamage(BoxHit2, WeaponHitBox2, retflag);
	if (retflag) return;

}


void ABossEnemy::ChangeMaterialToStageTwo()
{

	if (StageTwoMaterial && BossState == EBossState::EBS_StageTwo)
	{
		for (int32 Index = 0; Index <= MaterialIndex; ++Index)
		{
			GetMesh()->SetMaterial(Index, StageTwoMaterial);
		}
	}
}

void ABossEnemy::HideBossHealthBar()
{
	UWorld* World = GetWorld();

	if (World)
	{
		APlayerController* PlayerController = World->GetFirstPlayerController();

		if (EnemyController)
		{
			APlayerHUD* BossEnemyHUD = Cast<APlayerHUD>(PlayerController->GetHUD());
			if (BossEnemyHUD && BossHealthBar)
			{
				BossEnemyHUD->HideBossHealthBar();
			}
		}
	}
}

void ABossEnemy::EnagagedEnd()
{
	if (OutAttackRadius())
	{
		EnemyState = EEnemyState::EES_Chasing;
	}
	else
	{
		EnemyState = EEnemyState::EES_Attacking;
	}
	CurrentDefence = DefaultDefence;
}


void ABossEnemy::CoolAttackLogic(TArray<FName> attackSelection)
{
	if (IsPlayingAttackAnimation()) {
		return;
	}

	if (AttackMontageSelections.Num() <= 0) return;

	// ���݂̎��Ԃ��擾
	float CurrentTime = GetWorld()->GetTimeSeconds();

	// �g����̃A�^�b�N�^�C�v
	TArray<FName> OffCooldownAttacks;

	//�S�Ă̍U���^�C�v�̃N�[�����Ԃ��`���b�N
	for (const FName& AttackType : attackSelection) {
		float LastAttackTime = LastAttackTimes.Contains(AttackType) ? LastAttackTimes[AttackType] : 0.f;
		float CooldownTime = AttackCooldownTime.Contains(AttackType) ? AttackCooldownTime[AttackType] : 0.f;

		// �N�[�����Ԃ𒴂�����g����A�^�b�N�ɒǉ�
		if (CurrentTime - LastAttackTime >= CooldownTime) {
			OffCooldownAttacks.Add(AttackType);
		}
	}
	if (OffCooldownAttacks.Num() <= 0) return;

	// �N�[�����������X�L�����烉���_���g��
	const int32 Selection = FMath::RandRange(0, OffCooldownAttacks.Num() - 1);
	FName SelectedAttack = OffCooldownAttacks[Selection];

	if (!Attributes->IsAlive())
	{
		StopMontage(AttackMontage);
		return;
	}

	PlayMontageSection(AttackMontage, SelectedAttack);
	LastAttackTimes.Add(SelectedAttack, CurrentTime);
}

void ABossEnemy::PawnSeen(APawn* SeenPawn)
{
	const bool bShouldChaseTarget =
		EnemyState != EEnemyState::EES_Chasing &&
		EnemyState != EEnemyState::EES_Enagaged &&
		EnemyState != EEnemyState::EES_Attacking &&
		DeathPose == EDeathPose::EDP_Alive &&
		SeenPawn->ActorHasTag(FName("Player"));

	CombatTarget = SeenPawn;

	if (bShouldChaseTarget)
	{
		ChaseTarget();
	}

	if (!bIsBossHealthBarWidgetCreated)
	{
		CreateBossWidget();
	}

}

void ABossEnemy::CreateBossWidget()
{
	UWorld* World = GetWorld();
	if (World && EnemyController)
	{
		APlayerController* PlayerController = World->GetFirstPlayerController();

		APlayerHUD* BossEnemyHUD = Cast<APlayerHUD>(PlayerController->GetHUD());
		if (BossEnemyHUD)
		{
			BossEnemyHUD->ShowBossHealthBar();
			BossHealthBar = BossEnemyHUD->GetBossHealthBar();
			bIsBossHealthBarWidgetCreated = true;
		}
	}
}



