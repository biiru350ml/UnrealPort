// Fill out your copyright notice in the Description page of Project Settings.


#include "Enemy/Enemy.h"
#include "AIController.h"

#include"Components/SkeletalMeshComponent.h"
#include"Components/CapsuleComponent.h"
#include"Components/BoxComponent.h"
#include"Components/SceneComponent.h"
#include"Components/AttributeComponent.h"
#include"GameFramework/CharacterMovementComponent.h"
#include"Perception/PawnSensingComponent.h"
#include"HUD/HealthBarComponent.h"
#include"Characters/WorldPlayer.h"
#include"Projectile/Projectile.h"
#include"Kismet/KismetSystemLibrary.h"
#include"Kismet/GameplayStatics.h"
#include"Items/Soul.h"

#include"MyProject/DebugMacros.h"


AEnemy::AEnemy()
{
	PrimaryActorTick.bCanEverTick = true;

	GetMesh()->SetCollisionObjectType(ECollisionChannel::ECC_WorldDynamic);
	GetMesh()->SetCollisionResponseToChannel(ECollisionChannel::ECC_Visibility, ECollisionResponse::ECR_Block);
	GetMesh()->SetCollisionResponseToChannel(ECollisionChannel::ECC_Camera, ECollisionResponse::ECR_Ignore);
	GetMesh()->SetGenerateOverlapEvents(true);
	GetCapsuleComponent()->SetCollisionResponseToChannel(ECollisionChannel::ECC_Camera, ECollisionResponse::ECR_Ignore);


	HealthBarWidget = CreateDefaultSubobject<UHealthBarComponent>(TEXT("HealthBar"));
	HealthBarWidget->SetupAttachment(GetRootComponent());

	GetCharacterMovement()->bOrientRotationToMovement = true;
	bUseControllerRotationPitch = false;
	bUseControllerRotationYaw = false;
	bUseControllerRotationRoll = false;

	PawnSensing = CreateDefaultSubobject<UPawnSensingComponent>(TEXT("PawnSensing"));
	PawnSensing->SightRadius = 45.f;
	PawnSensing->SetPeripheralVisionAngle(45.f);

	WeaponHitBox = CreateDefaultSubobject<UBoxComponent>(TEXT("WeaponHitBox"));
	WeaponHitBox->SetupAttachment((GetRootComponent()));

	TraceStart = CreateDefaultSubobject<USceneComponent>(TEXT("TraceStart"));
	TraceStart->SetupAttachment(GetRootComponent());

	TraceEnd = CreateDefaultSubobject<USceneComponent>(TEXT("TraceEnd"));
	TraceEnd->SetupAttachment(GetRootComponent());


}

void AEnemy::BeginPlay()
{
	Super::BeginPlay();

	WeaponHitBox->OnComponentBeginOverlap.AddDynamic(this, &AEnemy::OnBoxOverlap);

	Tags.Add(FName("Enemy"));


	if (HealthBarWidget)
	{
		HealthBarWidget->SetVisibility(false);
	}

	EnemyController = Cast<AAIController>(GetController());

	StartPatrolling();


	if (PawnSensing)
	{
		PawnSensing->OnSeePawn.AddDynamic(this, &AEnemy::PawnSeen);
	}

	if (AttackMontage)
	{
		AttackMontage->RateScale = DefaultAttackRateScale;
	}

	CurrentDamageThreshold = DefaultDamageThreshold;
	CurrentAttackRateScale = DefaultAttackRateScale;

}

void AEnemy::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	if (CombatTarget)//�G�𔭌������狗���ɂ�蔻�肷��
	{
		CheckCombatTarget();
	}
	else
	{
		CheckPatrolTarget();
	}

	CheckDeathDistance();
}

void AEnemy::CheckDeathDistance()
{
	if (DeathPose != EDeathPose::EDP_Alive)
	{
		if (CombatTarget)
		{
			DeathDistance = (CombatTarget->GetActorLocation() - GetActorLocation()).Size();

			if (DeathDistance > CombatRadius - 20.f)
			{
				Destroy();
			}
		}
	}

}

void AEnemy::CheckPatrolTarget()
{
	if (InTargetRange(PatrolTarget, PatrolRadius))
	{
		PatrolTarget = ChoosePatrolTarget();
		const float WaitTime = FMath::RandRange(PatrolWaitMin, PatrolWaitMax);
		GetWorldTimerManager().SetTimer(PatrolTimer, this, &AEnemy::PatrolTimerFinished, WaitTime);

	}
}

/// <summary>
//�G�̃��C�����W�b�N
/// </summary>
void AEnemy::CheckCombatTarget()
{
	if (CombatTarget && OutCombatRadius())//�G�����邪�A�F�m�͈͊O�ɍs�����猳�̃p�g���[����Ԃɖ߂�
	{
		ClearAttackTimer();
		LoseInterest();
		if (!IsEngaged()) StartPatrolling();

	}
	else if (OutAttackRadius() && IsAlive() && ProjectileClasses.Num() == 0)//�������U����i���Ȃ���ΓG��ǐ�
	{
		ClearAttackTimer();

		ChaseTarget();

	}
	else if (InRangedAttackRadius() && IsAlive() && ProjectileClasses.Num() > 0 && !IsAttacking())//�������U����i������A�������U���͈͓��ł���΍U������
	{
		EnemyController->StopMovement();
		StartAttackTimer();
	}
	else if (InAttackRadius() && IsAlive() && !IsEngaged() && !IsAttacking())
	{
		StartAttackTimer();
	}
}

bool AEnemy::OutCombatRadius()
{
	return !InTargetRange(CombatTarget, CombatRadius);
}

bool AEnemy::OutAttackRadius()
{
	return !InTargetRange(CombatTarget, AttackRadius);
}

bool AEnemy::InRangedAttackRadius()
{
	return InTargetRange(CombatTarget, RangedAttackRadius);
}

bool AEnemy::InAttackRadius()
{
	return InTargetRange(CombatTarget, AttackRadius);
}

bool AEnemy::IsChasing()
{
	return EnemyState == EEnemyState::EES_Chasing;
}

bool AEnemy::IsAlive()
{
	return DeathPose == EDeathPose::EDP_Alive;
}

bool AEnemy::IsAttacking()
{
	return EnemyState == EEnemyState::EES_Attacking;
}

bool AEnemy::IsEngaged()
{
	//�������Z�������̃X�e�[�^�X
	return EnemyState == EEnemyState::EES_Enagaged;
}

void AEnemy::ClearPatrolTimer()
{
	GetWorldTimerManager().ClearTimer(PatrolTimer);
}

void AEnemy::ClearAttackTimer()
{
	GetWorldTimerManager().ClearTimer(AttackTimer);
}

void AEnemy::StartAttackTimer()
{
	EnemyState = EEnemyState::EES_Attacking;
	const float AttackTime = FMath::RandRange(AttackMin, AttackMax);
	GetWorldTimerManager().SetTimer(AttackTimer, this, &AEnemy::Attack, AttackTime);
}


bool AEnemy::InTargetRange(AActor* Target, double Radius)
{
	if (Target == nullptr)
	{
		return false;
	}
	double DistanceToTarget = (Target->GetActorLocation() - GetActorLocation()).Size();

	return DistanceToTarget <= Radius;
}

void AEnemy::MoveToTarget(AActor* Target)
{
	if (EnemyController == nullptr || Target == nullptr)
	{
		return;
	}
	if (Target == CombatTarget && InAttackRadius())
	{
		return;
	}

	FAIMoveRequest MoveRequest;
	MoveRequest.SetGoalActor(Target);
	MoveRequest.SetAcceptanceRadius(15.f);
	EnemyController->MoveTo(MoveRequest);

}

AActor* AEnemy::ChoosePatrolTarget()
{
	TArray<AActor*> ValidTargets;
	for (auto* Target : PatrolTargets)
	{
		if (Target != PatrolTarget)
		{
			ValidTargets.AddUnique(Target);
		}
	}
	const int32 NumPatrolTargets = ValidTargets.Num();
	if (NumPatrolTargets > 0)
	{
		const int32 TargetSelection = FMath::RandRange(0, NumPatrolTargets - 1);
		return  ValidTargets[TargetSelection];

	}
	return nullptr;
}

void AEnemy::PawnSeen(APawn* SeenPawn)
{
	const bool bShouldChaseTarget = ShouldChaseTarget(SeenPawn);

	CombatTarget = SeenPawn;

	if (bShouldChaseTarget)
	{
		ClearPatrolTimer();
		ChaseTarget();
	}
}

bool AEnemy::ShouldChaseTarget(APawn* SeenPawn)
{
	return EnemyState != EEnemyState::EES_Chasing &&
		EnemyState != EEnemyState::EES_Enagaged &&
		EnemyState != EEnemyState::EES_Attacking &&
		DeathPose == EDeathPose::EDP_Alive &&
		SeenPawn->ActorHasTag(FName("Player"));
}

void AEnemy::PlayMontageSection(UAnimMontage* Montage, const FName& SelectionName)
{
	UAnimInstance* AnimInstance = GetMesh()->GetAnimInstance();
	if (AnimInstance && Montage)
	{
		AnimInstance->Montage_Play(Montage);
		AnimInstance->Montage_JumpToSection(SelectionName, Montage);

	}
}

void AEnemy::EnableWeaponCollision()
{
	if (WeaponHitBox)
	{
		WeaponHitBox->SetCollisionEnabled(ECollisionEnabled::QueryOnly);

	}
	if (WeaponHitBox2)
	{
		WeaponHitBox2->SetCollisionEnabled(ECollisionEnabled::QueryOnly);

	}
}

void AEnemy::DisableWeaponCollsion()
{
	if (WeaponHitBox)
	{
		WeaponHitBox->SetCollisionEnabled(ECollisionEnabled::NoCollision);

		IgnoreActors.Empty();
	}
	if (WeaponHitBox2)
	{
		WeaponHitBox2->SetCollisionEnabled(ECollisionEnabled::NoCollision);

		IgnoreActors.Empty();
	}
}

void AEnemy::AttackEnd()
{
	EnemyState = EEnemyState::EES_NoState;

	CheckCombatTarget();
}

void AEnemy::LaunchProjectile(int32 projectileIndex)
{
	if (ProjectileClasses.IsValidIndex(projectileIndex) && CombatTarget)
	{
		//���˕������ꏊ�����߂�
		USkeletalMeshComponent* EnemyMesh = GetMesh();

		FName SocketName = "ProjectileSpawn";

		FVector SpawnLocation = EnemyMesh->GetSocketLocation(SocketName);
		FRotator SpawnRotation = EnemyMesh->GetSocketRotation(SocketName);

		//���˕��𐶐�����
		AProjectile* Projectile = GetWorld()->SpawnActor<AProjectile>(ProjectileClasses[projectileIndex], SpawnLocation, SpawnRotation);
		if (Projectile)
		{
			FVector DirectionToTarget = (CombatTarget->GetActorLocation() - SpawnLocation).GetSafeNormal();

			Projectile->LaunchProjectile(DirectionToTarget);
			Projectile->SetInstigatorController(GetController());

		}
	}
}

void AEnemy::HideHealthBar()
{
	if (HealthBarWidget)
	{
		HealthBarWidget->SetVisibility(false);
	}
}

void AEnemy::ShowHealthBar()
{
	if (HealthBarWidget)
	{
		HealthBarWidget->SetVisibility(true);
	}
}

void AEnemy::LoseInterest()
{
	CombatTarget = nullptr;
	HideHealthBar();
}

void AEnemy::StartPatrolling()
{
	EnemyState = EEnemyState::EES_Patrolling;
	GetCharacterMovement()->MaxWalkSpeed = PatrollingSpeed;
	MoveToTarget(PatrolTarget);
}

void AEnemy::ChaseTarget()
{
	EnemyState = EEnemyState::EES_Chasing;
	GetCharacterMovement()->MaxWalkSpeed = ChasingSpeed;

	MoveToTarget(CombatTarget);
}

void AEnemy::PatrolTimerFinished()
{
	if (DeathPose == EDeathPose::EDP_Alive)
	{
		MoveToTarget(PatrolTarget);
	}
}


void AEnemy::Die()
{
	UAnimInstance* AnimInstance = GetMesh()->GetAnimInstance();

	if (IsAlive() && AnimInstance && DeathMontage)
	{
		StopMontage(AttackMontage);
		AnimInstance->Montage_Play(DeathMontage);

		APlayerController* PlayerController = UGameplayStatics::GetPlayerController(GetWorld(), 0);
		AWorldPlayer* Player = Cast<AWorldPlayer>(PlayerController->GetPawn());

		Player->SetLock(false);//�v���C���[�̃��b�N������

		EnemyState = EEnemyState::EES_NoState;
		DisableWeaponCollsion();
		GetCapsuleComponent()->SetCollisionEnabled(ECollisionEnabled::NoCollision);

	}

	HideHealthBar();
	if (SoulClasses.Num() <= 0)//�\�E���Ȃǂ��Ȃ���Β��ڎ��S��Ԃɐ؂�ւ���
	{
		DeathPose = EDeathPose::EDP_Death1;
	}

	UWorld* World = GetWorld();
	if (World && SoulClasses.Num() > 0 && Attributes)
	{
		if (!IsAlive())
		{
			return;
		}

		const int32 Seclection = FMath::RandRange(1 - SoulClasses.Num(), SoulClasses.Num() - 1);
		const FVector SpawnLocation = GetActorLocation() + FVector(0.f, 0.f, 50.f);
		ASoul* SpawnedSoul = World->SpawnActor<ASoul>(SoulClasses[Seclection], SpawnLocation, GetActorRotation());
		DeathPose = EDeathPose::EDP_Death1;

		if (SpawnedSoul)
		{
			SpawnedSoul->SetSouls(Attributes->GetSoul());
		}

	}

}

void AEnemy::Attack()
{
	if (CombatTarget)
	{
		if (CombatTarget->ActorHasTag(FName("Dead")))
		{
			CombatTarget = nullptr;
			return;
		}
		//�U���A�j�����ł���Ή������Ȃ�
		if (IsPlayingAttackAnimation())
		{
			return;
		}
		PlayAttackMontage();
	}

}

void AEnemy::RangedAttack()
{

}

void AEnemy::GetHit_Implementation(const FVector& ImpactPoint, AActor* Hitter)
{

	if (IsAlive())ShowHealthBar();
	if (Attributes && Attributes->IsAlive() && Hitter)
	{
		if (EnemyState == EEnemyState::EES_Patrolling)
		{
			ClearPatrolTimer();
		}
		if (CurrentDamageThreshold <= 0)//���݂̃_���[�W��臒l��0�ȉ��ł���΃q�b�g�A�j�����Đ�
		{
			DisableWeaponCollsion();

			StopMontage(AttackMontage);
			EnemyController->StopMovement();

			DirectionalHitReact(ImpactPoint);

			CurrentDamageThreshold = DefaultDamageThreshold;//���݂̃_���[�W��臒l�����ɉ�
		}
	}
	else if (!Attributes->IsAlive())
	{
		Die();
	}

	PlayHitSound(ImpactPoint);
	PlayHitParticles(ImpactPoint);
}

void AEnemy::OnBoxOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
	if (ActorIsSameType(OtherActor))
	{
		return;
	}

	FHitResult BoxHit;
	FVector CollisionBoxExtent = WeaponHitBox->Bounds.BoxExtent;
	BoxHit = PerformWeaponTrace(TraceStart, TraceEnd, WeaponHitBox, CollisionBoxExtent);

	if (BoxHit.IsValidBlockingHit() && ActorIsSameType(BoxHit.GetActor()))
	{
		return;
	}

	bool retflag;
	ProcessDamage(BoxHit, WeaponHitBox, retflag);
	if (retflag)
	{
		return;
	}
}


bool AEnemy::ActorIsSameType(AActor* OtherActor)
{
	return OtherActor->ActorHasTag(FName("Enemy"));
}

float AEnemy::TakeDamage(float DamageAmount, FDamageEvent const& DamageEvent, AController* EventInstigator, AActor* DamageCauser)
{
	if (EventInstigator)
	{
		AActor* InstigatorActor = EventInstigator->GetPawn();

		if (Attributes && HealthBarWidget && !ActorIsSameType(InstigatorActor))
		{
			//�f�[�^����
			Attributes->ReceiveDamage(DamageAmount);
			if (CurrentDamageThreshold > 0)
			{
				CurrentDamageThreshold -= DamageAmount;
			}

			//HUD�\���X�V
			HealthBarWidget->SetHealthPercent(Attributes->GetHealthPercent());
			if (CombatTarget == nullptr)
			{
				CombatTarget = InstigatorActor;
			}
			if (!IsEngaged() && !IsChasing() && ProjectileClasses.Num() == 0)
			{
				ChaseTarget();
			}
		}
	}
	return DamageAmount;
}

