
#include "Characters/WorldPlayer.h"

#include"GameFramework/SpringArmComponent.h"
#include"Camera/CameraComponent.h"
#include"GameFramework/CharacterMovementComponent.h"
#include"Components/BoxComponent.h"
#include"Components/CapsuleComponent.h"
#include"Components/SceneComponent.h"
#include"Components/AttributeComponent.h"
#include"Animation/AnimMontage.h"
#include"Saves/MySaveGame.h"
#include"Items/Item.h"
#include "CameraShake/MyLegacyCameraShake.h"

#include "GameFramework/Character.h"
#include"HUD/PlayerHUD.h"
#include"HUD/PlayerOverlay.h"
#include"Interfaces/HitInterface.h"
#include"MyProject/DebugMacros.h"
#include"Items/Soul.h"
#include"Items/Treasure.h"

#include"Kismet/KismetSystemLibrary.h"
#include"Kismet/GameplayStatics.h"



AWorldPlayer::AWorldPlayer()
{

	PrimaryActorTick.bCanEverTick = true;

	bUseControllerRotationPitch = false;
	bUseControllerRotationYaw = false;
	bUseControllerRotationRoll = false;

	GetCharacterMovement()->bOrientRotationToMovement = true;
	GetCharacterMovement()->RotationRate = FRotator(0.f, 400.f, 0.f);

	GetMesh()->SetCollisionObjectType(ECollisionChannel::ECC_WorldDynamic);
	GetMesh()->SetCollisionResponseToAllChannels(ECollisionResponse::ECR_Ignore);
	GetMesh()->SetCollisionResponseToChannel(ECollisionChannel::ECC_Visibility, ECollisionResponse::ECR_Block);
	GetMesh()->SetCollisionResponseToChannel(ECollisionChannel::ECC_WorldDynamic, ECollisionResponse::ECR_Overlap);
	GetMesh()->SetGenerateOverlapEvents(true);

	SpringCam = CreateDefaultSubobject<USpringArmComponent>(TEXT("SpringArm"));
	SpringCam->SetupAttachment(GetRootComponent());
	SpringCam->TargetArmLength = 300.f;

	ViewCamera = CreateDefaultSubobject<UCameraComponent>(TEXT("ViewCamera"));
	ViewCamera->SetupAttachment(SpringCam);

	AutoPossessPlayer = EAutoReceiveInput::Player0;

	WeaponHitBox = CreateDefaultSubobject<UBoxComponent>(TEXT("WeaponHitBox"));
	WeaponHitBox->SetupAttachment((GetRootComponent()));

	InteractionBox = CreateDefaultSubobject<UBoxComponent>(TEXT("InteractBox"));
	InteractionBox->SetupAttachment((GetRootComponent()));

	TraceStart = CreateDefaultSubobject<USceneComponent>(TEXT("TraceStart"));
	TraceStart->SetupAttachment(GetRootComponent());

	TraceEnd = CreateDefaultSubobject<USceneComponent>(TEXT("TraceEnd"));
	TraceEnd->SetupAttachment(GetRootComponent());

}


void AWorldPlayer::LockOn()
{
	//�u���v�����g��IsLocked�ݒ�ς�
	if (IsLocked)
	{
		GetCharacterMovement()->MaxWalkSpeed = LockOnSpeed;
	}
	else
	{
		GetCharacterMovement()->MaxWalkSpeed = WalkSpeed;
	}

}

void AWorldPlayer::ResetCombo()
{
	AttackCount = 0;

	ActionState = EActionState::EAS_UnOccupied;

}

void AWorldPlayer::SaveAttack()
{
	AttackSaved = true;
}


void AWorldPlayer::Block()
{
	if (CanBlock())
	{
		ActionState = EActionState::EAS_Blocking;
		BlockBroken = false;
		AttackSaved = true;
		AttackCount = 0;
	}

}

bool AWorldPlayer::CanBlock()
{
	return IsAlive() && ActionState == EActionState::EAS_UnOccupied && IsLocked
		&& BlockModeOn;
}

void AWorldPlayer::BlockEnd()
{
	if (ActionState == EActionState::EAS_Blocking)
	{
		ActionState = EActionState::EAS_UnOccupied;
		BlockBroken = false;

	}
}

void ABaseCharacter::Landed(const FHitResult& Hit)
{
	Super::Landed(Hit);

	FVector Velocity = GetCharacterMovement()->Velocity;
	float FallSpeed = -Velocity.Z;
	// ���ȏ�̑��x�𒴂��΃_���[�W���󂯂�
	float FallDamage = 0.0f;
	if (FallSpeed > FallSpeedThreshold)
	{
		FallDamage = (FallSpeed - FallSpeedThreshold) * FallDamageFactor;
	}
	HandleFallDamage(FallDamage);
}

void AWorldPlayer::HandleFallDamage(float FallDamage)
{
	//�����̑��x�Ń_���[�W�����߂�
	if (Attributes && PlayerOverlay)
	{
		Attributes->ReceiveDamage(FallDamage);
		PlayerOverlay->SetHealthBarPercent(Attributes->GetHealthPercent());
		if (!Attributes->IsAlive())
		{
			Die();
		}
	}
}

void AWorldPlayer::BeginPlay()
{
	Super::BeginPlay();

	Tags.Add(FName("Player"));

	WeaponHitBox->OnComponentBeginOverlap.AddDynamic(this, &AWorldPlayer::OnWeaponBoxOverlap);
	InteractionBox->OnComponentBeginOverlap.AddDynamic(this, &AWorldPlayer::OnInteractBoxOverlap);
	InteractionBox->OnComponentEndOverlap.AddDynamic(this, &AWorldPlayer::EndInteractBoxOverlap);

	InitialzePlayerOverlay();

	if (AttackMontage)
	{
		AttackMontage->RateScale = DefaultAttackRateScale;
	}
	CurrentAttackRateScale = DefaultAttackRateScale;
}


void AWorldPlayer::InitialzePlayerOverlay()
{
	APlayerController* PlayerController = Cast<APlayerController>(GetController());

	if (PlayerController)
	{
		APlayerHUD* PlayerHUD = Cast<APlayerHUD>(PlayerController->GetHUD());
		if (PlayerHUD)
		{
			PlayerHUD->ShowPlayerOverlay();
			PlayerOverlay = PlayerHUD->GetPlayerOverlay();
			if (PlayerOverlay && Attributes)
			{
				PlayerOverlay->SetHealthBarPercent(Attributes->GetHealthPercent());
				PlayerOverlay->SetStaminaBarPercent(Attributes->GetStaminaPercent());
				PlayerOverlay->SetGold(0);
				PlayerOverlay->SetSoul(0);

			}
		}
	}
}

void AWorldPlayer::OnInteract()
{
	if (InteractionInterface && HasInteractableItem)
	{
		//�C���^���N�e�B�u�\�Ȏ�ނ�I��
		EInteractType InteractType = InteractionInterface->GetInteractType();

		switch (InteractType)
		{
		case EInteractType::EIT_Save:
			SaveGame();
			break;
		case EInteractType::EIT_ShowText:
			if (!InteractOn)
			{
				InteractionInterface->ShowText();
				InteractOn = true;
			}
			else
			{
				InteractionInterface->HideText();
				InteractOn = false;
			}
			break;
		default:
			break;
		}
	}
}

void AWorldPlayer::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);


	if (ActionState != EActionState::EAS_Rolling && IsInvincible && !InvincibleModeOn)
	{
		IsInvincible = false;
	}
	if (Attributes && PlayerOverlay && IsUnoccupied() && Attributes->GetStamina() != Attributes->GetMaxStamina())
	{
		Attributes->RegenStamina(DeltaTime);
		PlayerOverlay->SetStaminaBarPercent(Attributes->GetStaminaPercent());
	}
	if (Attributes && PlayerOverlay && ActionState == EActionState::EAS_Dashing)
	{
		Attributes->DashCostStamina(DeltaTime);
		PlayerOverlay->SetStaminaBarPercent(Attributes->GetStaminaPercent());
		if (Attributes->GetStamina() == 0.f)
		{
			DashEnd();
		}
	}
	else if (Attributes && PlayerOverlay)
	{
		PlayerOverlay->SetStaminaBarPercent(Attributes->GetStaminaPercent());
	}

	CheckClosestInteractItem();

}

void AWorldPlayer::CheckClosestInteractItem()
{

	if (!HasInteractableItem)
	{
		return;
	}


	InteractionBox->GetOverlappingActors(OverlappingActors);
	AActor* ClosestActor = OverlappingActors[0];

	//�v���C���[�Ɉ�ԋ߂����̂�I��
	for (auto* CurrentActor : OverlappingActors)
	{
		if (GetDistanceTo(CurrentActor) < GetDistanceTo(ClosestActor))
		{
			ClosestActor = CurrentActor;
		}
	}
	if (OverlappingActors.Num() == 0)
	{
		if (InteractionInterface)
		{
			InteractionInterface->HideInteractionWidget();
			InteractionInterface = nullptr;
		}
		return;
	}

	if (InteractionInterface)
	{
		InteractionInterface->HideInteractionWidget();
	}

	InteractionInterface = Cast<IInteractionInterface>(ClosestActor);

	if (InteractionInterface)
	{
		InteractionInterface->ShowInteractionWidget();
	}

}

void AWorldPlayer::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);

	PlayerInputComponent->BindAxis(FName("MoveForward"), this, &AWorldPlayer::MoveForward);
	PlayerInputComponent->BindAxis(FName("MoveRight"), this, &AWorldPlayer::MoveRight);
	PlayerInputComponent->BindAxis(FName("Turn"), this, &AWorldPlayer::Turn);
	PlayerInputComponent->BindAxis(FName("LookUp"), this, &AWorldPlayer::LookUp);

	PlayerInputComponent->BindAction(FName("Jump"), IE_Pressed, this, &AWorldPlayer::Jump);
	PlayerInputComponent->BindAction(FName("Interact"), IE_Pressed, this, &AWorldPlayer::OnInteract);
	PlayerInputComponent->BindAction(FName("Attack"), IE_Pressed, this, &AWorldPlayer::Attack);

	PlayerInputComponent->BindAction(FName("Roll"), IE_Pressed, this, &AWorldPlayer::Roll);
	PlayerInputComponent->BindAction(FName("Dash"), IE_Pressed, this, &AWorldPlayer::Dash);
	PlayerInputComponent->BindAction(FName("Dash"), IE_Released, this, &AWorldPlayer::DashEnd);
	PlayerInputComponent->BindAction(FName("Block"), IE_Pressed, this, &AWorldPlayer::Block);
	PlayerInputComponent->BindAction(FName("Block"), IE_Released, this, &AWorldPlayer::BlockEnd);

}

void AWorldPlayer::OnWeaponBoxOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
	FHitResult BoxHit;
	FVector CollisionBoxExtent = WeaponHitBox->Bounds.BoxExtent;

	BoxHit = PerformWeaponTrace(TraceStart, TraceEnd, WeaponHitBox, CollisionBoxExtent);

	bool retflag;
	ProcessDamage(BoxHit, WeaponHitBox, retflag);
	if (retflag)
	{
		return;
	}

	//�J������U��������
	APlayerCameraManager* CameraManager = UGameplayStatics::GetPlayerCameraManager(this, 0);
	if (CameraManager && MyCameraShake)
	{
		CameraManager->StartCameraShake(MyCameraShake, AttackCameraShakeFactor);
	}

	CreateFields(BoxHit.ImpactPoint);
}

void AWorldPlayer::GetHit_Implementation(const FVector& ImpactPoint, AActor* Hitter)
{
	bSuccessfullyBlockedLastHit = false;
	//���G�ł���Ή������Ȃ�
	if (IsInvincible)
	{
		return;
	}

	//�L�����������Ă���΃J������U���EHit�A�j���[�V�����N��
	if (Attributes && Attributes->IsAlive())
	{
		APlayerCameraManager* CameraManager = UGameplayStatics::GetPlayerCameraManager(this, 0);
		if (CameraManager && MyCameraShake)
		{
			CameraManager->StartCameraShake(MyCameraShake, HitReactCameraShakeFactor);
		}
		DirectionalHitReact(ImpactPoint);//�h�q�A�j��������Hit�A�j������

		if (bSuccessfullyBlockedLastHit)//�h�q���[�h�ł����Hit���ꂽ�T�E���h�Ȃǃv���C���Ȃ�
		{
			return;
		}

		ActionState = EActionState::EAS_HitReaction;
		PlayHitSound(ImpactPoint);
		PlayHitParticles(ImpactPoint);
		DisableWeaponCollsion(ECollisionEnabled::NoCollision);


	}
	else
	{
		Die();  // �����Ă��Ȃ���Ύ��S
	}
}

float AWorldPlayer::TakeDamage(float DamageAmount, FDamageEvent const& DamageEvent, AController* EventInstigator, AActor* DamageCauser)
{
	if (IsInvincible) return 0.f;

	if (PlayerOverlay && Attributes)
	{
		//�f�[�^����
		if (ActionState == EActionState::EAS_Blocking)
		{

			if (Attributes->GetStamina() > DamageAmount + BlockDamage && bSuccessfullyBlockedLastHit)//�U����h�����ꍇ
			{
				Attributes->UseStamina(DamageAmount + BlockDamage);
				PlayerOverlay->SetStaminaBarPercent(Attributes->GetStamina());

				return 0.f;
			}
			else if (Attributes->GetStamina() <= DamageAmount + BlockDamage)
			{
				Attributes->ReceiveDamage(DamageAmount / 4);
				PlayerOverlay->SetHealthBarPercent(Attributes->GetHealthPercent());
				Attributes->UseStamina(Attributes->GetStamina());
				PlayerOverlay->SetStaminaBarPercent(Attributes->GetStamina());
				BlockBroken = true;
				return 0.f;
			}
		}

		Attributes->ReceiveDamage(DamageAmount);

		//HUD�\���X�V
		PlayerOverlay->SetHealthBarPercent(Attributes->GetHealthPercent());

	}
	return DamageAmount;

}

void AWorldPlayer::HitReactEnd()
{
	SaveAttack();
	ResetCombo();

}

void AWorldPlayer::LockMovement()
{
	ActionState = EActionState::EAS_Occupied;
	AttackSaved = false;
}

void AWorldPlayer::Respawn()
{

	DeathPose = EDeathPose::EDP_Alive;
	ActionState = EActionState::EAS_UnOccupied;
	AttackSaved = true;
	if (Attributes && PlayerOverlay)
	{
		Attributes->HealthRecover(Attributes->GetMaxHealth());
		PlayerOverlay->SetHealthBarPercent(Attributes->GetHealthPercent());
		Attributes->StaminaRecover(Attributes->GetMaxStamina());
		PlayerOverlay->SetStaminaBarPercent(Attributes->GetStaminaPercent());
	}
}

void AWorldPlayer::InvincibleOn()
{
	IsInvincible = true;
}


void AWorldPlayer::MoveForward(float Value)
{
	if (ActionState != EActionState::EAS_Rolling)
	{
		InputY = Value;
	}
	if (!CanMove())
	{
		return;
	}

	if ((Controller != nullptr) && (Value != 0.f))
	{
		const FRotator ControlRotation = GetControlRotation();
		const FRotator YawRotation(0.f, ControlRotation.Yaw, 0.f);

		const FVector Direction = FRotationMatrix(YawRotation).GetUnitAxis(EAxis::X);
		AddMovementInput(Direction, Value);
	}
}

bool AWorldPlayer::CanMove()
{
	return (ActionState == EActionState::EAS_Dashing || ActionState == EActionState::EAS_UnOccupied ||
		ActionState == EActionState::EAS_Attacking || ActionState == EActionState::EAS_Blocking) &&
		IsAlive();
}

void AWorldPlayer::MoveRight(float Value)
{
	if (ActionState != EActionState::EAS_Rolling)
	{
		InputX = Value;
	}
	if (!CanMove())
	{
		return;
	}

	if ((Controller != nullptr) && (Value != 0.f))
	{
		const FRotator ControlRotation = GetControlRotation();
		const FRotator YawRotation(0.f, ControlRotation.Yaw, 0.f);

		const FVector Direction = FRotationMatrix(YawRotation).GetUnitAxis(EAxis::Y);
		AddMovementInput(Direction, Value);

	}
}

void AWorldPlayer::Turn(float Value)
{
	AddControllerYawInput(Value);
}

void AWorldPlayer::LookUp(float Value)
{
	AddControllerPitchInput(Value);

}


void AWorldPlayer::Dash()
{
	if (CanDash())
	{
		ActionState = EActionState::EAS_Dashing;
		GetCharacterMovement()->MaxWalkSpeed = DashSpeed;
	}

}

bool AWorldPlayer::CanDash()
{
	return !IsLocked && !IsPlayingAttackAnimation() && !IsPlayingHitReactAnimation()
		&& Attributes->IsAlive() && ActionState == EActionState::EAS_UnOccupied;
}

void AWorldPlayer::DashEnd()
{
	if (ActionState == EActionState::EAS_Dashing)
	{
		ActionState = EActionState::EAS_UnOccupied;
		GetCharacterMovement()->MaxWalkSpeed = WalkSpeed;
	}
}

void AWorldPlayer::Jump()
{
	if (IsUnoccupied() && IsAlive())
	{
		Super::Jump();
	}
}

bool AWorldPlayer::IsUnoccupied()
{
	return ActionState == EActionState::EAS_UnOccupied;
}

bool AWorldPlayer::IsAlive()
{
	return DeathPose == EDeathPose::EDP_Alive;
}

void AWorldPlayer::Attack()
{
	if (CanAttack())
	{
		ActionState = EActionState::EAS_Attacking;

		PlayAttackMontage();
	}
}

//BluePrint�Ŏ��s
void AWorldPlayer::Roll()
{
	if (Attributes && PlayerOverlay && CanRoll())
	{
		if (IsPlayingAttackAnimation())
		{
			StopAnimMontage(AttackMontage);
		}
		ResetCombo();
		//BluePrint��True�ɕϊ�
		if (!AttributeRoll && Attributes->GetStamina() > Attributes->GetRollCost())
		{
			Attributes->UseStamina(Attributes->GetRollCost());
			PlayerOverlay->SetStaminaBarPercent(Attributes->GetStaminaPercent());
		}

	}

}

bool AWorldPlayer::CanRoll()
{
	bool EnoughStamina = Attributes->GetStamina() > Attributes->GetRollCost();

	return EnoughStamina && (!IsPlayingHitReactAnimation()) &&
		((ActionState == EActionState::EAS_UnOccupied) || (AttackSaved));
}

void AWorldPlayer::InvincibleOff()
{
	IsInvincible = false;
}

bool AWorldPlayer::CanAttack()
{
	bool EnoughStamina;
	if (Attributes->GetStamina() > Attributes->GetAttackCost())
	{
		EnoughStamina = true;
	}
	else
	{
		EnoughStamina = false;
	}
	return ((ActionState == EActionState::EAS_UnOccupied || ActionState == EActionState::EAS_Attacking) && (AttackSaved)) &&
		DeathPose == EDeathPose::EDP_Alive && EnoughStamina;
}

void AWorldPlayer::Die()
{
	UAnimInstance* AnimInstance = GetMesh()->GetAnimInstance();

	if (AnimInstance && DeathMontage)
	{
		if (DeathPose == EDeathPose::EDP_Alive)
		{
			AnimInstance->Montage_Play(DeathMontage);
		}
		DeathPose = EDeathPose::EDP_Death1;
		ActionState = EActionState::EAS_Occupied;
		DisableWeaponCollsion(ECollisionEnabled::NoCollision);
		Tags.Add(FName("Dead"));

		CallDeathWidget();
	}
}

//���S��ʂ��Ăяo��
void AWorldPlayer::CallDeathWidget()
{
	if (ActiveDeathWidget)// ���łɕ\������Ă��牽�����Ȃ�
	{
		return;
	}

	UUserWidget* DeathWidget = CreateWidget<UUserWidget>(GetWorld(), DeathWidgetClass);
	if (DeathWidget)
	{
		DeathWidget->AddToViewport();
		ActiveDeathWidget = DeathWidget;

		APlayerController* PlayerController = GetWorld()->GetFirstPlayerController();
		if (PlayerController)
		{
			PlayerController->SetInputMode(FInputModeGameAndUI());
			PlayerController->bShowMouseCursor = true;
		}
	}
}

void AWorldPlayer::CallWidget(TSubclassOf<UUserWidget> widget)
{
	UUserWidget* Widget = CreateWidget<UUserWidget>(GetWorld(), widget);
	if (Widget)
	{
		Widget->AddToViewport();
	}
}

void AWorldPlayer::EnableWeaponCollision(ECollisionEnabled::Type QueryOnly)
{
	if (WeaponHitBox)
	{
		WeaponHitBox->SetCollisionEnabled(QueryOnly);
	}
}

void AWorldPlayer::DisableWeaponCollsion(ECollisionEnabled::Type NoCollsion)
{
	if (WeaponHitBox)
	{
		WeaponHitBox->SetCollisionEnabled(NoCollsion);
		IgnoreActors.Empty();
	}
}

void AWorldPlayer::PlayMontageSection(UAnimMontage* Montage, const FName& SelectionName)
{
	UAnimInstance* AnimInstance = GetMesh()->GetAnimInstance();
	if (AnimInstance && Montage)
	{
		AnimInstance->Montage_Play(Montage);

		AnimInstance->Montage_JumpToSection(SelectionName, Montage);

	}
}

void AWorldPlayer::PlayAttackMontage()
{
	UAnimInstance* AnimInstance = GetMesh()->GetAnimInstance();
	if (AnimInstance && Attributes)
	{
		if (AttackSaved)
		{
			AnimInstance->Montage_Play(AttackMontage);
			AttackCount++;
			Attributes->UseStamina(Attributes->GetAttackCost());

			switch (AttackCount)
			{
			case 1:
				AttackSaved = false;
				AnimInstance->Montage_JumpToSection("Attack1", AttackMontage);
				break;
			case 2:
				AttackSaved = false;
				AnimInstance->Montage_JumpToSection("Attack2", AttackMontage);
				break;
			case 3:
				AttackSaved = false;
				AnimInstance->Montage_JumpToSection("Attack3", AttackMontage);
				break;
			case 4:
				AttackSaved = false;
				AnimInstance->Montage_JumpToSection("Attack4", AttackMontage);
				break;
			default:
				break;
			}
		}

	}

}

void AWorldPlayer::SaveGame()
{
	SaveGameInstance = Cast<UMySaveGame>(UGameplayStatics::CreateSaveGameObject(UMySaveGame::StaticClass()));
	if (SaveGameInstance)
	{
		SaveGameInstance->PlayerLocation = GetActorTransform();

		SaveGameInstance->MaxHealth = Attributes->GetMaxHealth();
		SaveGameInstance->MaxStamina = Attributes->GetMaxStamina();
		SaveGameInstance->GoldAmount = Attributes->GetGold();
		SaveGameInstance->SoulAmount = Attributes->GetSoul();
		SaveGameInstance->ObtainedRedSoulNum = Attributes->GetRedSoulNum();
		SaveGameInstance->ObtainedGreenSoulNum = Attributes->GetGreenSoulNum();

		SaveGameInstance->ObtainedSoulsStates = ObtainedSoulsStates;

		UGameplayStatics::AsyncSaveGameToSlot(SaveGameInstance, TEXT("SaveSlot"), 0, FAsyncSaveGameToSlotDelegate::CreateUObject(this, &AWorldPlayer::OnGameSaved));
	}
}

void AWorldPlayer::OnGameSaved(const FString& SlotName, const int32 UserIndex, bool bSuccess)
{
	if (bSuccess)
	{
		CallWidget(SaveWidgetClass);
	}
	else
	{
		GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, TEXT("Save Failed!"));
	}
}

void AWorldPlayer::LoadGameAsync()
{
	UGameplayStatics::AsyncLoadGameFromSlot(TEXT("SaveSlot"), 0, FAsyncLoadGameFromSlotDelegate::CreateUObject(this, &AWorldPlayer::LoadGame));
}


void AWorldPlayer::LoadGame(const FString& SlotName, const int32 UserIndex, USaveGame* LoadedGame)
{
	SaveGameInstance = Cast<UMySaveGame>(LoadedGame);
	if (SaveGameInstance && Attributes && PlayerOverlay)
	{
		SetActorLocation(SaveGameInstance->PlayerLocation.GetLocation());
		SetActorRotation(SaveGameInstance->PlayerLocation.GetRotation());

		float MaxHealth = Attributes->GetMaxHealth();
		float MaxStamina = Attributes->GetMaxStamina();

		Attributes->SetMaxHealth(SaveGameInstance->MaxHealth);
		Attributes->SetMaxStamina(SaveGameInstance->MaxStamina);
		Attributes->SetGoldAmount(SaveGameInstance->GoldAmount);
		Attributes->SetSoulAmount(SaveGameInstance->SoulAmount);
		Attributes->SetRedSoulNum(SaveGameInstance->ObtainedRedSoulNum);
		Attributes->SetGreenSoulNum(SaveGameInstance->ObtainedGreenSoulNum);

		PlayerOverlay->UpdateHealthBar(Attributes->GetMaxHealth(), MaxHealth);
		PlayerOverlay->SetHealthBarPercent(Attributes->GetHealthPercent());
		PlayerOverlay->UpdateStaminaBar(Attributes->GetMaxStamina(), MaxStamina);
		PlayerOverlay->SetStaminaBarPercent(Attributes->GetStaminaPercent());
		PlayerOverlay->SetRedSoulNum(Attributes->GetRedSoulNum());
		PlayerOverlay->SetGreenSoulNum(Attributes->GetGreenSoulNum());

		//�}�b�v���̃\�E�����`�F�b�N
		TArray<AActor*> FoundSouls;
		UGameplayStatics::GetAllActorsOfClass(GetWorld(), ASoul::StaticClass(), FoundSouls);

		for (AActor* Actor : FoundSouls)
		{
			ASoul* Soul = Cast<ASoul>(Actor);
			if (Soul != nullptr)
			{
				//���W�ς݂̃\�E�����B��
				bool* ObtainedState = SaveGameInstance->ObtainedSoulsStates.Find(Soul->SoulIndex);
				if (ObtainedState != nullptr)
				{
					Soul->SetActorHiddenInGame(true);
					Soul->SetActorEnableCollision(false);
					Soul->SetActorTickEnabled(false);;

				}
			}
		}

	}
}




void AWorldPlayer::OnInteractBoxOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
	HasInteractableItem = true;
}

void AWorldPlayer::EndInteractBoxOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex)
{
	HasInteractableItem = false;
	if (InteractionInterface)
	{
		InteractionInterface->HideInteractionWidget();
		//Text���\�����Ă���Ε���
		if (InteractionInterface->GetInteractType() == EInteractType::EIT_ShowText)
		{
			InteractionInterface->HideText();
			InteractOn = false;
		}
	}
}


void AWorldPlayer::AddSouls(ASoul* Soul)
{
	if (Attributes && PlayerOverlay)
	{
		Attributes->AddSoul(Soul->GetSouls());
		PlayerOverlay->SetSoul(Attributes->GetSoul());
	}
}

void AWorldPlayer::HealBySoul(ASoul* Soul)
{
	if (Attributes && PlayerOverlay)
	{
		Attributes->HealthRecover(Soul->GetHealAmount());
		PlayerOverlay->SetHealthBarPercent(Attributes->GetHealthPercent());
	}
}

void AWorldPlayer::IncreaseMaxStaminaBySoul(ASoul* Soul)
{
	if (Attributes && PlayerOverlay)
	{
		float MaxStamina = Attributes->GetMaxStamina();
		Attributes->SetMaxStamina(MaxStamina + Soul->GetIncreaseMaxStaminaAmount());
		PlayerOverlay->UpdateStaminaBar(Attributes->GetMaxStamina(), MaxStamina);
		PlayerOverlay->SetStaminaBarPercent(Attributes->GetStaminaPercent());
	}
}

void AWorldPlayer::IncreaseMaxHealthBySoul(ASoul* Soul)
{
	if (Attributes && PlayerOverlay)
	{
		float MaxHealth = Attributes->GetMaxHealth();
		Attributes->SetMaxHealth(MaxHealth + Soul->GetIncreaseMaxHealthAmount());
		PlayerOverlay->UpdateHealthBar(Attributes->GetMaxHealth(), MaxHealth);
		PlayerOverlay->SetHealthBarPercent(Attributes->GetHealthPercent());
	}
}

void AWorldPlayer::AddObtainedRedSoul(ASoul* ObtainedSouls)
{
	if (Attributes && PlayerOverlay)
	{
		int32 SoulIndex = ObtainedSouls->SoulIndex;
		bool SoulState = ObtainedSouls->bObtained;
		ObtainedSoulsStates.Add(SoulIndex, SoulState);

		Attributes->SetRedSoulNum(Attributes->GetRedSoulNum() + 1);
		PlayerOverlay->SetRedSoulNum(Attributes->GetRedSoulNum());
	}
}

void AWorldPlayer::AddObtainedGreenSoul(ASoul* ObtainedSouls)
{
	if (Attributes && PlayerOverlay)
	{
		int32 SoulIndex = ObtainedSouls->SoulIndex;
		bool SoulState = true;
		ObtainedSoulsStates.Add(SoulIndex, SoulState);

		Attributes->SetGreenSoulNum(Attributes->GetGreenSoulNum() + 1);
		PlayerOverlay->SetGreenSoulNum(Attributes->GetGreenSoulNum());

	}
}

void AWorldPlayer::AddGold(ATreasure* Treasure)
{
	if (Attributes && PlayerOverlay)
	{
		Attributes->AddGold(Treasure->GetGold());
		PlayerOverlay->SetGold(Attributes->GetGold());
	}
}

void AWorldPlayer::SetOverlappingItem(AItem* Item)
{
	OverlappingItem = Item;
}

