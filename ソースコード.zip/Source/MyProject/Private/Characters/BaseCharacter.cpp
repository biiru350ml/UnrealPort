// Fill out your copyright notice in the Description page of Project Settings.


#include "Characters/BaseCharacter.h"
#include"Components/BoxComponent.h"
#include"Kismet/GameplayStatics.h"
#include"Components/AttributeComponent.h"
#include"MyProject/DebugMacros.h"


// Sets default values
ABaseCharacter::ABaseCharacter()
{

	PrimaryActorTick.bCanEverTick = true;

	Attributes = CreateDefaultSubobject<UAttributeComponent>(TEXT("Attributes"));
}

void ABaseCharacter::BeginPlay()
{
	Super::BeginPlay();


}
void ABaseCharacter::Block()
{
}
void ABaseCharacter::BlockEnd()
{
}
void ABaseCharacter::BlockBrokenEnd()
{
	BlockBroken = false;
	ActionState = EActionState::EAS_UnOccupied;
}
void ABaseCharacter::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}

void ABaseCharacter::ResetTimeAndAnimationSpeed()
{
	//���Ԃ����ɖ߂�
	UGameplayStatics::SetGlobalTimeDilation(GetWorld(), 1.0f);

	// �A�j���̑��x�����ɖ߂�
	UAnimInstance* AnimInstance = GetMesh()->GetAnimInstance();
	if (AnimInstance && AttackMontage)
	{
		AnimInstance->Montage_SetPlayRate(AttackMontage, CurrentAttackRateScale);
	}
}

void ABaseCharacter::Attack()
{

}

void ABaseCharacter::RangedAttack()
{
}

void ABaseCharacter::AttackEnd()
{
	ActionState = EActionState::EAS_UnOccupied;
}


void ABaseCharacter::Die()
{
}


void ABaseCharacter::PlayAttackMontage()
{
	if (AttackMontageSelections.Num() <= 0) return;
	//�����_���A�^�b�N
	const int32 MaxSectionIndex = AttackMontageSelections.Num() - 1;
	const int32 Selection = FMath::RandRange(0, MaxSectionIndex);
	if (!Attributes->IsAlive())
	{
		StopMontage(AttackMontage);
		AttackEnd();
		return;
	}
	PlayMontageSection(AttackMontage, AttackMontageSelections[Selection]);

}

void ABaseCharacter::PlayMontage(UAnimMontage* Montage)
{
	UAnimInstance* AnimInstance = GetMesh()->GetAnimInstance();

	if (AnimInstance && Montage)
	{
		AnimInstance->Montage_Stop(0.0f);
		AnimInstance->Montage_Play(Montage);
	}
}


void ABaseCharacter::PlayRespawnMontageMontage()
{
	UAnimInstance* AnimInstance = GetMesh()->GetAnimInstance();

	if (AnimInstance && RespawnMontage)
	{
		AnimInstance->Montage_Play(RespawnMontage);
	}
}

void ABaseCharacter::PlayRollMontage()
{

	if (ActionState != EActionState::EAS_UnOccupied) return;
	UAnimInstance* AnimInstance = GetMesh()->GetAnimInstance();
	if (AnimInstance && Attributes && Attributes->GetStamina() > Attributes->GetRollCost())
	{
		AnimInstance->Montage_Play(RollMontage);
	}
}



void ABaseCharacter::StopMontage(UAnimMontage* Montage)
{
	UAnimInstance* AnimInstance = GetMesh()->GetAnimInstance();
	if (AnimInstance)
	{

		AnimInstance->Montage_Stop(0.f, Montage);
	}
}

FVector ABaseCharacter::GetTranslationWarpTarget()
{

	if (CombatTarget == nullptr) return FVector();

	const FVector CombatTargetLocation = CombatTarget->GetActorLocation();
	const FVector Location = GetActorLocation();

	FVector TargetToMe = (Location - CombatTargetLocation).GetSafeNormal();
	TargetToMe *= WarpTargetDistance;

	return CombatTargetLocation + TargetToMe;
}

FVector ABaseCharacter::GetRotationWarpTarget()
{
	if (CombatTarget)
	{
		return CombatTarget->GetActorLocation();
	}

	return FVector();

}

FHitResult ABaseCharacter::PerformWeaponTrace(USceneComponent* traceStart, USceneComponent* traceEnd, UBoxComponent* weaponBox, FVector halfSize)
{
	const FVector Start = traceStart->GetComponentTransform().GetLocation();
	const FVector End = traceEnd->GetComponentTransform().GetLocation();

	TArray<AActor*> ActorsToIgnore;
	AActor* OwnerActor = weaponBox->GetOwner();
	ActorsToIgnore.AddUnique(Cast<AActor>(OwnerActor));//���̍U���͈��̂݃g���[�X���N��

	for (AActor* Actor : IgnoreActors)
	{
		ActorsToIgnore.AddUnique(Actor);
	}
	FHitResult BoxHit;
	UKismetSystemLibrary::BoxTraceSingle(
		weaponBox,
		Start,
		End,
		halfSize,
		traceStart->GetComponentRotation(),
		ETraceTypeQuery::TraceTypeQuery1,
		false,
		ActorsToIgnore,
		EDrawDebugTrace::None,
		BoxHit,
		true
	);
	return BoxHit;
}

bool ABaseCharacter::IsPlayingAttackAnimation()
{
	UAnimInstance* AnimInstance = GetMesh()->GetAnimInstance();
	if (AnimInstance)
	{
		return AnimInstance->Montage_IsPlaying(AttackMontage);
	}
	return false;
}

bool ABaseCharacter::IsPlayingHitReactAnimation()
{
	UAnimInstance* AnimInstance = GetMesh()->GetAnimInstance();
	if (AnimInstance)
	{
		return AnimInstance->Montage_IsPlaying(HitReactMontage);
	}
	return false;
}

void ABaseCharacter::ProcessDamage(FHitResult& BoxHit, UBoxComponent* weaponBox, bool& retflag)
{
	retflag = true;

	if (BoxHit.GetActor() && GetInstigator() && GetInstigator()->GetController())
	{
		UGameplayStatics::ApplyDamage(
			BoxHit.GetActor(),
			NormalDamage,
			GetInstigator()->GetController(),
			Cast<AActor>(weaponBox),
			UDamageType::StaticClass()
		);

		IHitInterface* HitInterface = Cast<IHitInterface>(BoxHit.GetActor());
		if (HitInterface)
		{
			HitInterface->Execute_GetHit(BoxHit.GetActor(), BoxHit.ImpactPoint, GetOwner());
		}
		IgnoreActors.AddUnique(BoxHit.GetActor());

		//�U��������ꎞ�~�܂�A�Ō��������߂�
		UAnimInstance* AnimInstance = GetMesh()->GetAnimInstance();
		if (AnimInstance && AttackMontage)
		{
			AnimInstance->Montage_SetPlayRate(AttackMontage, 0.01f);
		}
		GetWorldTimerManager().SetTimer(TH_TimeDilation, this, &ABaseCharacter::ResetTimeAndAnimationSpeed, 0.04f, false);
	}

	retflag = false;
}

void ABaseCharacter::PlayHitReactMontage(const FName& SelectionName)
{
	UAnimInstance* AnimInstance = GetMesh()->GetAnimInstance();

	if (AnimInstance && HitReactMontage)
	{
		AnimInstance->Montage_Play(HitReactMontage);

		AnimInstance->Montage_JumpToSection(SelectionName, HitReactMontage);
	}
}

void ABaseCharacter::PlayHitSound(const FVector& ImpactPoint)
{
	if (HitSound)
	{
		UGameplayStatics::PlaySoundAtLocation(
			this,
			HitSound,
			ImpactPoint
		);
	}
}

void ABaseCharacter::PlayHitParticles(const FVector& ImpactPoint)
{
	if (HitParticles)
	{
		UGameplayStatics::SpawnEmitterAtLocation(
			GetWorld(),
			HitParticles,
			ImpactPoint
		);
	}
}

double ABaseCharacter::DirectionalHitReact(const FVector& ImpactPoint)
{

	const FVector Forward = GetActorForwardVector();
	const FVector ImpactLowered(ImpactPoint.X, ImpactPoint.Y, GetActorLocation().Z);

	FVector ToHit = (ImpactLowered - GetActorLocation());
	if (ToHit.IsNearlyZero())
	{
		//�f�t�H���g�U���󂯂����
		ToHit = Forward;
	}
	else
	{
		//�q�b�g�ʒu�̐��K��
		ToHit.Normalize();
	}

	//Forward * ToHit = |Forward||ToHit| * cos(Theta) = 1*1*cos(Theta)
	const double CosTheta = FVector::DotProduct(Forward, ToHit);

	//arc(cos(theta)) = theta 
	double Theta = FMath::Acos(CosTheta);

	//���W�A������x�ɕϊ�
	Theta = FMath::RadiansToDegrees(Theta);

	if (FVector::CrossProduct(Forward, ToHit).Z < 0)
	{
		Theta *= -1.f;
	}

	FName Selection("FromBack");
	if (Theta >= -45.f && Theta < 45.f)
	{
		Selection = FName("FromFront");
		UE_LOG(LogTemp, Warning, TEXT("FromFront"));
	}
	else if (Theta >= -135.f && Theta < -45.f)
	{
		Selection = FName("FromLeft");
		UE_LOG(LogTemp, Warning, TEXT("FromLeft"));

	}
	else if (Theta >= 45.f && Theta < 135.f)
	{
		Selection = FName("FromRight");
		UE_LOG(LogTemp, Warning, TEXT("FromRight"));
	}


	if (ActionState == EActionState::EAS_Blocking && Theta >= -60.f && Theta < 60.f)
	{
		if (BlockBroken)//�h�䂪���ꂽ�ꍇ
		{
			ActionState = EActionState::EAS_Occupied;
			PlayMontage(BlockBrokenMontage);
			bSuccessfullyBlockedLastHit = false;
			return Theta;
		}
		else
		{
			PlayMontage(BlockImpactMontage);
			bSuccessfullyBlockedLastHit = true;
			return Theta;
		}
	}
	//�h�q���[�h�łȂ���΃q�b�g�A�j���g�p
	else
	{
		PlayHitReactMontage(Selection);
		return Theta;
	}

}

void ABaseCharacter::PlayMontageSection(UAnimMontage* Montage, const FName& SelectionName)
{

}

void ABaseCharacter::HandleFallDamage(float FallHeight)
{

}





