// Fill out your copyright notice in the Description page of Project Settings.


#include "Characters/PlayerAnimInstance.h"
#include"Characters/WorldPlayer.h"
#include"GameFramework/CharacterMovementComponent.h"
#include"Kismet/KismetMathLibrary.h"


void UPlayerAnimInstance::NativeInitializeAnimation()
{
	Super::NativeInitializeAnimation();

	
	WorldPlayer = Cast<AWorldPlayer>(TryGetPawnOwner());

	if (WorldPlayer)
	{
		

		WorldPlayerMovement = WorldPlayer->GetCharacterMovement();
	}
}

void UPlayerAnimInstance::NativeUpdateAnimation(float Deltatime)
{
	Super::NativeUpdateAnimation(Deltatime);

	if (WorldPlayerMovement)
	{
		GroundSpeed = UKismetMathLibrary::VSizeXY(WorldPlayerMovement->Velocity);
		IsFalling = WorldPlayerMovement->IsFalling();
		ActionState = WorldPlayer->GetActionState();
		DeathPose = WorldPlayer->GetDeathPose();


	}
}
