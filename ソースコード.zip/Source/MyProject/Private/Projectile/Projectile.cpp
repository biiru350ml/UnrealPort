// Fill out your copyright notice in the Description page of Project Settings.


#include "Projectile/Projectile.h"
#include"Components/SphereComponent.h"
#include "Components/AudioComponent.h"
#include "Kismet/GameplayStatics.h"
#include "NiagaraComponent.h"
#include "NiagaraSystem.h"
#include "NiagaraFunctionLibrary.h"
#include"Characters/WorldPlayer.h"
#include "GameFramework/ProjectileMovementComponent.h"

// Sets default values
AProjectile::AProjectile()
{
	PrimaryActorTick.bCanEverTick = true;

	SphereCollisionComponent = CreateDefaultSubobject<USphereComponent>(TEXT("SphereComponent"));
	SphereCollisionComponent->SetNotifyRigidBodyCollision(true);
	SphereCollisionComponent->SetCollisionProfileName(TEXT("Projectile"));
	RootComponent = SphereCollisionComponent;

	MovementComponent = CreateDefaultSubobject<UProjectileMovementComponent>(TEXT("ProjectileMovementComponent"));
	MovementComponent->SetUpdatedComponent(SphereCollisionComponent);
	MovementComponent->InitialSpeed = 300.0f;
	MovementComponent->MaxSpeed = 300.0f;
	MovementComponent->bRotationFollowsVelocity = true;
	MovementComponent->ProjectileGravityScale = 0.0f; // no gravity

	ParticleTrail = CreateDefaultSubobject<UNiagaraComponent>(TEXT("ParticleTrail"));
	ParticleTrail->SetupAttachment(SphereCollisionComponent);

	AudioComponent = CreateDefaultSubobject<UAudioComponent>(TEXT("AudioComponent"));
	AudioComponent->SetupAttachment(RootComponent);

}

void AProjectile::BeginPlay()
{
	Super::BeginPlay();
	if (SphereCollisionComponent)
	{
		SphereCollisionComponent->OnComponentHit.AddDynamic(this, &AProjectile::OnHit);
	}

	GetWorldTimerManager().SetTimer(LifeTimerHandle, this, &AProjectile::CheckProjectileLife, LifeSpan, false);

	if (FlyingSound != nullptr)
	{
		AudioComponent->SetSound(FlyingSound);
		AudioComponent->Play();
	}
}

void AProjectile::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}

void AProjectile::LaunchProjectile(FVector Direction)
{
	MovementComponent->Velocity = Direction * MovementComponent->InitialSpeed;

	UNiagaraFunctionLibrary::SpawnSystemAttached(
		TrailEffect,
		SphereCollisionComponent,
		NAME_None,
		FVector::ZeroVector,
		FRotator::ZeroRotator,
		EAttachLocation::SnapToTarget,
		true,
		true,
		ENCPoolMethod::AutoRelease
	);

}

void AProjectile::ApplyDamage(AActor* Target)
{
	UGameplayStatics::ApplyDamage(Target, Damage, InstigatorController, this, nullptr);
}

void AProjectile::SetInstigatorController(AController* Controller)
{
	if(Controller)
	{
		InstigatorController = Controller;
	}
}

void AProjectile::OnHit(UPrimitiveComponent* HitComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, FVector NormalImpulse, const FHitResult& Hit)
{
	if (bHasExploded)
	{
		return;
	}

	if ((OtherActor != nullptr) && (OtherActor != this) && (OtherComp != nullptr) && !bHasExploded)
	{
		AWorldPlayer* Player = Cast<AWorldPlayer>(OtherActor);

		//�����������̂̓v�����^�[�ł���΃_���[�W��^����
		if (Player)
		{
			UGameplayStatics::ApplyDamage(Player, Damage, InstigatorController, this, nullptr);
		}
		if (ImpactEffect)
		{
			UNiagaraFunctionLibrary::SpawnSystemAtLocation(
				GetWorld(),
				ImpactEffect,
				GetActorLocation(),
				GetActorRotation()
			);

		}
		IHitInterface* HitInterface = Cast<IHitInterface>(Hit.GetActor());
		if (HitInterface)
		{
			HitInterface->Execute_GetHit(Hit.GetActor(), Hit.ImpactPoint, GetOwner());
		}

		AudioComponent->SetSound(ImpactSound);
		AudioComponent->Play();

		FTimerHandle TimerHandle;
		GetWorld()->GetTimerManager().SetTimer(TimerHandle, this, &AProjectile::DestroyProjectile, 0.2f, false);



		bHasExploded = true;
	}

}

void AProjectile::CheckProjectileLife()
{
	if (!bHasExploded)
	{
		bHasExploded = true;
		if (SphereCollisionComponent)
		{
			SphereCollisionComponent->OnComponentHit.Clear();
		}
		Destroy();

	}
}

void AProjectile::DestroyProjectile()
{
	Destroy();
}


