// Fill out your copyright notice in the Description page of Project Settings.


#include "Breakable/BreakableActor.h"
#include"GeometryCollection/GeometryCollectionComponent.h"
#include"Components/BoxComponent.h"

#include"Items/Treasure.h"
ABreakableActor::ABreakableActor()
{

	PrimaryActorTick.bCanEverTick = false;

	GeometryCollection = CreateDefaultSubobject<UGeometryCollectionComponent>(TEXT("GeometryCollection"));
	SetRootComponent(GeometryCollection);
	GeometryCollection->SetGenerateOverlapEvents(true);
	GeometryCollection->SetCollisionResponseToChannel(ECollisionChannel::ECC_Camera, ECollisionResponse::ECR_Ignore);
	GeometryCollection->SetCollisionResponseToChannel(ECollisionChannel::ECC_Pawn, ECollisionResponse::ECR_Ignore);

	Box = CreateDefaultSubobject<UBoxComponent>(TEXT("Box"));
	Box->SetupAttachment(GetRootComponent());
	Box->SetCollisionResponseToAllChannels(ECollisionResponse::ECR_Ignore);
	Box->SetCollisionResponseToChannel(ECollisionChannel::ECC_Pawn, ECollisionResponse::ECR_Block);
}


void ABreakableActor::BeginPlay()
{
	Super::BeginPlay();

}

// Called every frame
void ABreakableActor::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

void ABreakableActor::GetHit_Implementation(const FVector& ImpactPoint, AActor* Hitter)
{
	if (bBroken)
	{
		return;
	}
	bBroken = true;

	Box->SetCollisionResponseToChannel(ECollisionChannel::ECC_Pawn, ECollisionResponse::ECR_Ignore);


	UWorld* World = GetWorld();
	const int32 Seclection = FMath::RandRange(2 - TreasureClasses.Num(), TreasureClasses.Num() - 1);
	if (World && TreasureClasses.Num() > 0 && Seclection >= 0)
	{
		FVector Location = GetActorLocation();
		Location.Z -= 25.f;
		World->SpawnActor<ATreasure>(TreasureClasses[Seclection], Location, GetActorRotation());

		float Lifespan = 2.f;
		SetLifeSpan(Lifespan);
	}
}

