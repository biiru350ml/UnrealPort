// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/HUD.h"
#include "PlayerHUD.generated.h"

/**
 * 
 */
class UPlayerOverlay;
class UHealthBar;

UCLASS()
class MYPROJECT_API APlayerHUD : public AHUD
{
	GENERATED_BODY()

protected:

	virtual void BeginPlay()override;

private:

	UPROPERTY(EditDefaultsOnly, Category = Player)
	TSubclassOf<UPlayerOverlay> PlayerOverlayClass;

	UPROPERTY(EditDefaultsOnly, Category = Boss)
	TSubclassOf<UHealthBar> BossHealthBarClass;

	UPROPERTY()
	UPlayerOverlay* PlayerOverlay;

	UPROPERTY()
	UHealthBar* BossHealthBar;

public:

	void ShowBossHealthBar();

	void HideBossHealthBar();

	void ShowPlayerOverlay();


	FORCEINLINE UPlayerOverlay* GetPlayerOverlay() const { return PlayerOverlay; }
	FORCEINLINE UHealthBar* GetBossHealthBar() const { return BossHealthBar; }


};
