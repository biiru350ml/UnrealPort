// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "PlayerOverlay.generated.h"

/**
 * 
 */
UCLASS()
class MYPROJECT_API UPlayerOverlay : public UUserWidget
{
	GENERATED_BODY()


public:

	void NativeTick(const FGeometry& MyGeometry, float DeltaTime)override;

	void SetHealthBarPercent(float Percent);
	void SetStaminaBarPercent(float Percent);
	void SetHitBarPercent(float Percent);
	void SetGold(int32 Gold);
	void SetSoul(int32 Soul);
	void SetRedSoulNum(int32 redSoulNum);
	void SetGreenSoulNum(int32 greenSoulNum);

	void UpdateHealthBar(float CurrentMaxHealth, float MaxHealth);
	void UpdateStaminaBar(float CurrentMaxStamina, float MaxStamina);

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Stamina Bar")
	float StaminaBarUpdateSpeed = 1.f;

	float TargetStamina = 1.f;

private:
	float const DefaultHealthBarLength = 450.f;
	float const DefaultStaminaBarLength = 340.f;

	UPROPERTY()
	FTimerHandle StaminaBarTimerHandle;

	UPROPERTY(meta = (BindWidget))
	class UProgressBar* HealthBar;

	UPROPERTY(meta = (BindWidget))
	class UProgressBar* BottomStaminaBar;

	UPROPERTY(meta = (BindWidget))
	class UProgressBar* TopStaminaBar;

	UPROPERTY(meta = (BindWidget))
	class UProgressBar* HitBar;

	UPROPERTY(meta = (BindWidget))
	class UTextBlock* GoldCount;

	UPROPERTY(meta = (BindWidget))
	class UTextBlock* SoulCount;

	UPROPERTY(meta = (BindWidget))
	class UTextBlock* RedSoulNum;

	UPROPERTY(meta = (BindWidget))
	class UTextBlock* GreenSoulNum;

};
