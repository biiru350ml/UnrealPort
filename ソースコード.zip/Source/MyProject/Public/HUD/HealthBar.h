// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "HealthBar.generated.h"

/**
 * 
 */
UCLASS()
class MYPROJECT_API UHealthBar : public UUserWidget
{
	GENERATED_BODY()

public:

	void NativeTick(const FGeometry& MyGeometry, float DeltaTime)override;

	void SetBossHealthBarPercent(float Percent);

	void SetBossName(FString bossName);

	UPROPERTY(meta = (BindWidget))
	class UProgressBar* TopHealthBar;//WBP_HealthBar�̃l�[�~���O�Ɠ����K�v������

	UPROPERTY(meta = (BindWidget))
	class UProgressBar* BottomHealthBar;


	UPROPERTY(meta = (BindWidget))
	class UTextBlock* BossName;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Health Bar")
	float HealthBarUpdateSpeed = 1.f;
};
