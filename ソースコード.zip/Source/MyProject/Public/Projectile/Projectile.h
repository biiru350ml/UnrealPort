// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Projectile.generated.h"

class USphereComponent;
class UNiagaraComponent;
class UNiagaraSystem;
class UProjectileMovementComponent;

UCLASS()
class MYPROJECT_API AProjectile : public AActor
{
	GENERATED_BODY()
	
public:	
	AProjectile();

	virtual void Tick(float DeltaTime) override;

	void LaunchProjectile(FVector Direction);

	void ApplyDamage(AActor* Target);

	void SetInstigatorController(AController* Controller);

protected:
	virtual void BeginPlay() override;

	// Components
	UPROPERTY(VisibleAnywhere, Category = "Components")
	UStaticMeshComponent* MeshComponent;

	UPROPERTY(VisibleAnywhere, Category = "Components")
	USphereComponent* SphereCollisionComponent;

	UPROPERTY(VisibleAnywhere, Category = "Components")
	UProjectileMovementComponent* MovementComponent;

	UPROPERTY(VisibleAnywhere, Category = "Components")
	UNiagaraComponent* ParticleTrail;

	// Effects
	UPROPERTY(EditAnywhere, Category = "Effects")
	UNiagaraSystem* ImpactEffect;

	UPROPERTY(EditAnywhere, Category = "Effects")
	UNiagaraSystem* TrailEffect;

	// Attributes
	UPROPERTY(EditAnywhere, Category = "Projectile Attributes")
	float Speed = 200.f;

	UPROPERTY(EditAnywhere, Category = "Projectile Attributes")
	float Damage = 20.f;

	UPROPERTY(EditAnywhere, Category = "Projectile Attributes")
	float LifeSpan = 5.0f;

	//Sound
	UPROPERTY(EditDefaultsOnly, Category = "Sound")
	UAudioComponent* AudioComponent;

	UPROPERTY(EditAnywhere, Category = "Sound")
	USoundBase* FlyingSound;

	UPROPERTY(EditAnywhere, Category = "Sound")
	USoundBase* ImpactSound;

	UFUNCTION()
	void OnHit(UPrimitiveComponent* HitComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, FVector NormalImpulse, const FHitResult& Hit);

	void CheckProjectileLife();

private:

	void DestroyProjectile();

	
	AController* InstigatorController = nullptr;

	FTimerHandle LifeTimerHandle;

	bool bHasExploded = false;




};
