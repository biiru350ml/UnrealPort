// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include"Interfaces/InteractionInterface.h"
#include"Components/WidgetComponent.h"
#include "InteractableItem.generated.h"

UCLASS()
class MYPROJECT_API AInteractableItem : public AActor, public IInteractionInterface
{
	GENERATED_BODY()
	
public:	
	AInteractableItem();

protected:
	virtual void BeginPlay() override;

public:	
	virtual void Tick(float DeltaTime) override;

	virtual void ShowText() override;
	virtual void HideText() override;

	virtual void ShowInteractionWidget() override;

	virtual void HideInteractionWidget() override;
	
	virtual EInteractType GetInteractType() override;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI")
	TSubclassOf<UUserWidget> TextWidgetClass;

	UPROPERTY(EditAnywhere)
	UUserWidget* TextWidget;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	EInteractType InteractType;
private:
	UPROPERTY(EditAnywhere)
	USceneComponent* MyRootComponent;

	UPROPERTY(EditAnywhere)
	UStaticMeshComponent* MyMesh;

	UPROPERTY(EditAnywhere)
	UWidgetComponent* InteractionWidget;

	


	

	


};
