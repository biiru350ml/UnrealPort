// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Engine/AssetManager.h"
#include "GameAssetManager.generated.h"

DECLARE_DYNAMIC_DELEGATE(FOnPackageLoaded);

/**
 * 
 */

UCLASS(Blueprintable)
class MYPROJECT_API UGameAssetManager : public UAssetManager
{
	GENERATED_BODY()
public:
	FString CurrentLoadPackage;

public:
	UFUNCTION(BlueprintPure, CallInEditor, DisplayName = "GameAssetManager")
	static UGameAssetManager* Get();

	UFUNCTION(BlueprintCallable, CallInEditor)
	FString MyAsyncLoadObject(FSoftObjectPath Path, FOnPackageLoaded OnPackageLoaded);
	UFUNCTION(BlueprintCallable, CallInEditor)
	float GetCurrentLoadProgress(int32& LoadedCount, int32& RequestedCount) const;
};
