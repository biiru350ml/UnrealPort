#pragma once

UENUM(BlueprintType)
enum class EDeathPose : uint8
{
	EDP_Alive,
	EDP_Death1,
	EDP_Death2,
	EDP_Death3,
	EDP_Death4,
};
UENUM(BlueprintType)
enum class EEnemyState : uint8
{
	EES_NoState,
	EES_Patrolling,
	EES_Chasing,
	EES_Attacking,
	EES_Enagaged,
};

UENUM(BlueprintType)
enum class EActionState : uint8
{
	EAS_UnOccupied,
	EAS_HitReaction,
	EAS_Attacking,
	EAS_Dashing,
	EAS_Blocking,
	EAS_Rolling,
	EAS_Occupied
};

