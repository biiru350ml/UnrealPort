// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include"BaseCharacter.h"
#include"Interfaces/InteractionInterface.h"
#include"Interfaces/PickUpInterface.h"
#include "WorldPlayer.generated.h"

class USpringArmComponent;
class UCameraComponent;
class AItem;
class ASoul;
class Treasure;
class UAnimMontage;
class UBoxComponent;
class UPlayerOverlay;
class UMySaveGame;
class USaveGame;
class UMyLegacyCameraShake;


UCLASS()
class MYPROJECT_API AWorldPlayer : public ABaseCharacter, public IPickUpInterface, public IInteractionInterface
{
	GENERATED_BODY()

public:
	
	AWorldPlayer();

	virtual void Tick(float DeltaTime) override;



	//Interactions
	void GetHit_Implementation(const FVector& ImpactPoint, AActor* Hitter);

	UFUNCTION()
	void OnWeaponBoxOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp,
		int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
	UFUNCTION()
	void OnInteractBoxOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp,
			int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
	UFUNCTION()
	void EndInteractBoxOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp,
			int32 OtherBodyIndex);

	void CheckClosestInteractItem();

	float TakeDamage(float DamageAmount, struct FDamageEvent const& DamageEvent,
		class AController* EventInstigator, AActor* DamageCauser);

	//Inventory
	virtual void AddSouls(ASoul* Soul) override;
	virtual void HealBySoul(ASoul* Soul)override;
	virtual void IncreaseMaxStaminaBySoul(ASoul* Soul)override;
	virtual void IncreaseMaxHealthBySoul(ASoul* Soul)override;
	virtual void AddObtainedRedSoul(ASoul* ObtainedSouls)override;
	virtual void AddObtainedGreenSoul(ASoul* ObtainedSouls)override;
	virtual void AddGold(ATreasure* Treasure) override;
	virtual void SetOverlappingItem(class AItem* Item) override;

	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = Movement)
	float InputX = 0.f;
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = Movement)
	float InputY = 0.f;

	//Lock

	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Lock")
	bool IsLocked = false;

	UFUNCTION(BlueprintCallable)
	void LockOn();
	UFUNCTION(BlueprintCallable)
	bool GetLock() const { return IsLocked; }
	UFUNCTION(BlueprintCallable)
	void SetLock(bool value) { IsLocked = value; }

	//Combo
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite)
	int32 AttackCount = 0;
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite)
	bool AttackSaved = true;
	
	
	//Block
	virtual void Block() override;
	bool CanBlock();
	virtual void BlockEnd() override;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float BlockDamage = 50.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	bool IsInvincible = false;

	//falling
	virtual void HandleFallDamage(float FallHeight) override;

protected:
	virtual void BeginPlay() override;
	
	//Input
	virtual void SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent) override;
	void MoveForward(float Value);
	void MoveRight(float Value);
	void Turn(float Value);
	void LookUp(float Value);

	//Movement
	void Dash();
	bool CanDash();
	void DashEnd();
	virtual void Jump()override;
	virtual void Attack() override;
	void Roll();

	//Blueprint function
	UFUNCTION(BlueprintCallable)
	void ResetCombo();
	UFUNCTION(BlueprintCallable)
	void SaveAttack();
	UFUNCTION(BlueprintCallable)
	void InvincibleOn();
	UFUNCTION(BlueprintCallable)
	void InvincibleOff();
	UFUNCTION(BlueprintCallable)
	void HitReactEnd();
	UFUNCTION(BlueprintCallable)
	void LockMovement();
	UFUNCTION(BlueprintCallable)
	void Respawn();
	UFUNCTION(BlueprintCallable)
	bool CanRoll();
	bool CanMove();
	bool CanAttack();
	bool IsUnoccupied();
	bool IsAlive();

	virtual void Die()override;

	UFUNCTION(BlueprintCallable)
	void CallDeathWidget();

	UFUNCTION(BlueprintCallable)
	void CallWidget(TSubclassOf<UUserWidget> widget);

	UFUNCTION(BlueprintImplementableEvent)
	void CreateFields(const FVector& FieldLocation);//�j��ł�����̗p

	UFUNCTION(BlueprintCallable)
	void EnableWeaponCollision(ECollisionEnabled::Type QueryOnly);

	UFUNCTION(BlueprintCallable)
	void DisableWeaponCollsion(ECollisionEnabled::Type NoCollision);

	void PlayMontageSection(UAnimMontage* Montage, const FName& SelecionName) override;

	void PlayAttackMontage() override;

	//SaveAndLoad
	UFUNCTION(BlueprintCallable)
	void SaveGame();
	UFUNCTION(BlueprintCallable)
	void LoadGameAsync();
	void LoadGame(const FString& SlotName, const int32 UserIndex, USaveGame* LoadedGame);
	void OnGameSaved(const FString& SlotName, const int32 UserIndex, bool bSuccess);
	UMySaveGame* SaveGameInstance;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SaveGame")
	TMap<int32, bool> ObtainedSoulsStates;

	UPROPERTY(VisibleAnywhere,BlueprintReadWrite)
	UBoxComponent* WeaponHitBox;

	TArray<AActor*> OverlappingActors;

	UPROPERTY(VisibleAnywhere, BlueprintReadWrite)
	USceneComponent* TraceStart;

	UPROPERTY(VisibleAnywhere, BlueprintReadWrite)
	USceneComponent* TraceEnd;

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "UI")
	TSubclassOf<UUserWidget> DeathWidgetClass;

	UUserWidget* ActiveDeathWidget = nullptr;

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "UI")
	TSubclassOf<UUserWidget> SaveWidgetClass;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	bool AttributeRoll = false;//Roll�̐��l�����pBool

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Camera Shake")
	TSubclassOf<UMyLegacyCameraShake> MyCameraShake;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Camera Shake")
	float HitReactCameraShakeFactor = 0.1f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Camera Shake")
	float AttackCameraShakeFactor = 0.2f;

	UPROPERTY(VisibleAnywhere)
	bool HasInteractableItem;

	UPROPERTY(VisibleAnywhere)
	bool InteractOn = false;//�C���^���N�e�B�u�{�^�����������ǂ���

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Cheat")
	bool BlockModeOn = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Cheat")
	bool InvincibleModeOn = false;
private:

	void InitialzePlayerOverlay();

	void OnInteract();

	UPROPERTY(VisibleAnywhere)
	USpringArmComponent* SpringCam;

	UPROPERTY(VisibleAnywhere)
	UCameraComponent* ViewCamera;

	UPROPERTY(VisibleAnywhere)
	UBoxComponent* InteractionBox;

	UPROPERTY(VisibleInstanceOnly)
	AItem* OverlappingItem;

	UPROPERTY()
	UPlayerOverlay* PlayerOverlay;

	IInteractionInterface* InteractionInterface;

	UPROPERTY(EditAnywhere, Category = Combat)
	float LockOnSpeed = 300.f;
	UPROPERTY(EditAnywhere, Category = Combat)
	float WalkSpeed = 600.f;
	UPROPERTY(EditAnywhere, Category = Combat)
	float DashSpeed = 900.f;

public:
	FORCEINLINE EDeathPose GetDeathPose() const { return DeathPose; }
	FORCEINLINE EActionState GetActionState() const { return ActionState; }

};
