// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include"Interfaces/HitInterface.h"
#include "CharacterTypes.h"

#include "BaseCharacter.generated.h"



class AItem;
class UAnimMontage;
class UBoxComponent;
class UAttributeComponent;


UCLASS()
class MYPROJECT_API ABaseCharacter : public ACharacter, public IHitInterface
{
	GENERATED_BODY()

public:

	ABaseCharacter();
	virtual void Tick(float DeltaTime) override;

protected:
	
	//�A�^�b�N�A�j���ꎞ�~�܂�p�^�C���n���h��
	FTimerHandle TH_TimeDilation;

	void ResetTimeAndAnimationSpeed();

	//Land Damage
	UPROPERTY(EditDefaultsOnly)
	float FallSpeedThreshold;

	UPROPERTY(EditDefaultsOnly)
	float FallDamageFactor;

	UFUNCTION(BlueprintCallable)
	virtual void HandleFallDamage(float FallHeight);

	virtual void Landed(const FHitResult& Hit) override;

	virtual void BeginPlay() override;

	virtual void Block();

	UFUNCTION(BlueprintCallable)
	virtual void BlockEnd();

	UFUNCTION(BlueprintCallable)
	virtual void BlockBrokenEnd();
	
	virtual void Attack();

	virtual void RangedAttack();

	UFUNCTION(BlueprintCallable)
	virtual void AttackEnd();

	virtual void Die();

	UFUNCTION()
	void ProcessDamage(FHitResult& BoxHit, UBoxComponent* weaponBox, bool& retflag);

	void PlayHitReactMontage(const FName& SelectionName);
	void PlayHitSound(const FVector& ImpactPoint);
	void PlayHitParticles(const FVector& ImpactPoint);
	double DirectionalHitReact(const FVector& ImpactPoint);

	virtual void PlayMontageSection(UAnimMontage* Montage, const FName& SelecionName);

	virtual void PlayAttackMontage();

	virtual void PlayMontage(UAnimMontage* Montage);

	virtual void PlayRespawnMontageMontage();

	void PlayRollMontage();

	void StopMontage(UAnimMontage* Montage);

	UFUNCTION(BlueprintCallable)
	FVector GetTranslationWarpTarget();

	UFUNCTION(BlueprintCallable)
	FVector GetRotationWarpTarget();

	UFUNCTION(BlueprintCallable)
	float GetDamage() const { return NormalDamage; }

	UFUNCTION()
	FHitResult PerformWeaponTrace(USceneComponent* traceStart, USceneComponent* traceEnd, UBoxComponent* weaponBox, FVector halfSize);

	bool IsPlayingAttackAnimation();
	bool IsPlayingHitReactAnimation();

	UPROPERTY(VisibleAnywhere)
	TArray<AActor*> IgnoreActors;

	UPROPERTY(EditAnywhere, Category = Combat)
	TArray<FName> AttackMontageSelections;

	//�A�j�������^�[�W��
	UPROPERTY(EditDefaultsOnly, Category = Montages)
	UAnimMontage* AttackMontage;

	UPROPERTY(EditDefaultsOnly, Category = Montages)
	UAnimMontage* BlockImpactMontage;

	UPROPERTY(EditDefaultsOnly, Category = Montages)
	UAnimMontage* BlockBrokenMontage;

	UPROPERTY(EditDefaultsOnly, Category = Montages)
	UAnimMontage* RollMontage;

	UPROPERTY(EditDefaultsOnly, Category = Montages)
	UAnimMontage* HitReactMontage;

	UPROPERTY(EditDefaultsOnly, Category = Montages)
	UAnimMontage* DeathMontage;

	UPROPERTY(EditDefaultsOnly, Category = Montages)
	UAnimMontage* RespawnMontage;

	UPROPERTY(VisibleAnywhere,BlueprintReadOnly)
	UAttributeComponent* Attributes;

	UPROPERTY(EditAnywhere, CateGory = Sounds)
	USoundBase* HitSound;

	UPROPERTY(EditAnywhere, CateGory = VisualEffects)
	UParticleSystem* HitParticles;

	UPROPERTY(BlueprintReadOnly, Category = Combat)
	AActor* CombatTarget;

	UPROPERTY(BlueprintReadWrite)
	EDeathPose DeathPose = EDeathPose::EDP_Alive;

	UPROPERTY(BlueprintReadWrite)
	EActionState ActionState = EActionState::EAS_UnOccupied;

	UPROPERTY(EditAnywhere, Category = Combat)
	double WarpTargetDistance = 75.f;

	UPROPERTY(EditAnywhere)
	bool BlockBroken = false;

	UPROPERTY(EditAnywhere, Category = "Damage")
	float NormalDamage = 20.f;

	UPROPERTY(EditAnywhere, Category = "Damage")
	float HitterDamage = 0.f;

	UPROPERTY(EditAnywhere, Category = "Montage")
	float DefaultAttackRateScale;

	UPROPERTY(EditAnywhere, Category = "Montage")
	float CurrentAttackRateScale;

	bool bSuccessfullyBlockedLastHit = false;
};
