// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "AttributeComponent.generated.h"

class ASoul;
UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class MYPROJECT_API UAttributeComponent : public UActorComponent
{
	GENERATED_BODY()

public:	
	
	UAttributeComponent();

	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;
	void RegenStamina(float DeltaTime);
	void DashCostStamina(float DeltaTime);

protected:

	virtual void BeginPlay() override;

private:

	UPROPERTY(EditAnywhere, Category = "Actor Attributes")
	float Health = 100.f;

	UPROPERTY(EditAnywhere, Category = "Actor Attributes")
	float MaxHealth = 100.f;

	UPROPERTY(EditAnywhere, Category = "Actor Attributes")
	float Stamina =100.f;

	UPROPERTY(EditAnywhere, Category = "Actor Attributes")
	float MaxStamina = 100.f;

	UPROPERTY(EditAnywhere, Category = "Actor Attributes")
	float RollCost = 24.f;

	UPROPERTY(EditAnywhere, Category = "Actor Attributes")
	float AttackCost = 35.f;

	UPROPERTY(EditAnywhere, Category = "Actor Attributes")
	float StaminaRegenRate = 8.f;

	UPROPERTY(EditAnywhere, Category = "Actor Attributes")
	float StaminaDashCostRate = 10.f;

	UPROPERTY(EditAnywhere, Category = "Actor Attributes")
	int32 Gold = 0;

	UPROPERTY(EditAnywhere, Category = "Actor Attributes")
	int32 Soul = 0;

	UPROPERTY(EditAnywhere, Category = "Actor Attributes")
	int32 RedSoulNum = 0;

	UPROPERTY(EditAnywhere, Category = "Actor Attributes")
	int32 GreenSoulNum = 0;

public:
	void ReceiveDamage(float Damage);
	void UseStamina(float StaminaCost);
	void HealthRecover(float Value);
	void StaminaRecover(float Value);
	void SetMaxHealth(float Value);
	void SetSoulAmount(int32 soul);
	void SetGoldAmount(int32 gold);
	void SetMaxStamina(float Value);
	void SetRedSoulNum(int32 value);
	void SetGreenSoulNum(int32 value);
	float GetHealthPercent();
	float GetStaminaPercent();



	bool IsAlive();

	void AddGold(int32 NumberOfGold);
	void AddSoul(int32 NumberOfsouls);

	float GetCurrentHealth() { return Health; }
	FORCEINLINE int32 GetGold() const { return Gold; }
	FORCEINLINE int32 GetSoul() const { return Soul; }
	FORCEINLINE int32 GetRedSoulNum() const { return RedSoulNum; }
	FORCEINLINE int32 GetGreenSoulNum() const { return GreenSoulNum; }
	FORCEINLINE float GetRollCost() const { return RollCost; }
	FORCEINLINE float GetAttackCost() const { return AttackCost; }
	FORCEINLINE float GetStamina() const { return Stamina; }
	FORCEINLINE float GetMaxStamina() const { return MaxStamina; }
	FORCEINLINE float GetHealth() const { return Health; }
	FORCEINLINE float GetMaxHealth() const { return MaxHealth; }
	



};
