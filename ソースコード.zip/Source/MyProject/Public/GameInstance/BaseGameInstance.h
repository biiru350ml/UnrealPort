// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Engine/GameInstance.h"
#include "BaseGameInstance.generated.h"

/**
 * 
 */
UENUM(BlueprintType)
enum class EMusicType : uint8
{
	EMT_None,
	EMT_MainMenu,
	EMT_MainLevel1,
	EMT_Boss,
	EMT_BossStageTwo,
	EMT_Vectory
};

UCLASS()
class MYPROJECT_API UBaseGameInstance : public UGameInstance
{
	GENERATED_BODY()

	UBaseGameInstance();

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Music")
	EMusicType MusicType;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Music")
	UAudioComponent* MusicRef;
};
