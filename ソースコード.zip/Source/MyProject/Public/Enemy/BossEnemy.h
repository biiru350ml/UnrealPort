// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Enemy/Enemy.h"
#include "BossEnemy.generated.h"

/**
 * 
 */
class UHealthBar;

UENUM(BlueprintType)
enum class EBossState : uint8
{
	EBS_Normal,
	EBS_StageTwo,
	EBS_StageThree
};

UCLASS()
class MYPROJECT_API ABossEnemy : public AEnemy
{
	GENERATED_BODY()

public:
	ABossEnemy();

	virtual void Tick(float DeltaTime) override;

protected:
	virtual void BeginPlay() override;

	virtual void Attack() override;

	virtual void RangedAttack() override;

	virtual void PlayAttackMontage() override;

	virtual void GetHit_Implementation(const FVector& ImpactPoint, AActor* Hitter) override;

	virtual float TakeDamage(float DamageAmount, struct FDamageEvent const& DamageEvent,
		class AController* EventInstigator, AActor* DamageCauser)override;

	void StageChange(UAnimMontage* stageChangeMontage, float stageAttackCollDownRate, float stageAttackSpeedRate, float stageChasingSpeedRate, TArray< FName> newAttackName);

	virtual void OnBoxOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp,
		int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult) override;

	void CoolAttackLogic(TArray<FName> attackSelection);

	UFUNCTION(BlueprintCallable)
	void ChangeMaterialToStageTwo();

	UFUNCTION(BlueprintCallable)
	void HideBossHealthBar();

	UFUNCTION(BlueprintCallable)
	void EnagagedEnd();

	virtual void PawnSeen(APawn* SeenPawn) override;

	void CreateBossWidget();


	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Boss Behavior")
	TMap< FName, float> AttackCooldownTime;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Boss Behavior")
	TMap<FName, float> LastAttackTimes;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Boss Behavior")
	TArray< FName> RangedAttackName;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Boss Behavior")
	TArray< FName> StageTwoAttackName;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Boss Behavior")
	float StageTwoChasingSpeedRate = 1.5f;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Boss Behavior")
	float StageTwoAttackSpeedRate = 1.6f;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Boss Behavior")
	float StageTwoAttackCoolDownRate = 0.8f;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Boss Behavior")
	float CurrentDefence = 0.f;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Boss Behavior")
	float DefaultDefence = 0.f;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Boss Behavior")
	float DefenceFactor = 0.6f;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Boss Behavior")
	float StageTwoHealthLine = 0.5f;

	UPROPERTY(EditDefaultsOnly, Category = "Boss Behavior")
	int32 MaterialIndex;

	UPROPERTY(EditDefaultsOnly, Category = Montages)
	UAnimMontage* StageChangeTwoMontage;

	UPROPERTY(EditDefaultsOnly, Category = Montages)
	UAnimMontage* StageChangeThreeMontage;

	UPROPERTY(BlueprintReadWrite)
	EBossState BossState = EBossState::EBS_Normal;

	UPROPERTY(EditAnywhere)
	UMaterialInterface* StageTwoMaterial;

	UPROPERTY(EditAnywhere)
	UMaterialInterface* StageThreeMaterial;

private:
	
	UPROPERTY()
	UHealthBar* BossHealthBar;

	bool bIsBossHealthBarWidgetCreated = false;

	FName CurrentAttackType;

};
