// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include"Characters/BaseCharacter.h"
#include "Characters/CharacterTypes.h"
#include"Interfaces/HitInterface.h"

#include "Enemy.generated.h"



class UHealthBarComponent;
class UPawnSensingComponent;
class AItem;
class UAnimMontage;
class UBoxComponent;
class UAttributeComponent;


UCLASS()
class MYPROJECT_API AEnemy : public ABaseCharacter
{
	GENERATED_BODY()

public:
	AEnemy();

	virtual void Tick(float DeltaTime) override;

	virtual void GetHit_Implementation(const FVector& ImpactPoint,AActor* Hitter);

	/*Actor*/
	virtual float TakeDamage(float DamageAmount, struct FDamageEvent const& DamageEvent,
				class AController* EventInstigator, AActor* DamageCauser);

	UFUNCTION()
	virtual void OnBoxOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp,
				int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);

	UFUNCTION(BlueprintCallable)
	virtual void PawnSeen(APawn* SeenPawn);

	bool ShouldChaseTarget(APawn* SeenPawn);

	bool ActorIsSameType(AActor* OtherActor);

protected:
	virtual void BeginPlay() override;

	virtual void Attack() override;

	virtual void RangedAttack() override;

	virtual void Die() override;

	bool InTargetRange(AActor* Target, double Radius);
	void MoveToTarget(AActor* Target);

	AActor* ChoosePatrolTarget();

	UFUNCTION(BlueprintImplementableEvent)
	void CreateFields(const FVector& FieldLocation);

	void PlayMontageSection(UAnimMontage* Montage, const FName& SelecionName) override;

	UFUNCTION(BlueprintCallable)
	void EnableWeaponCollision();

	UFUNCTION(BlueprintCallable)
	void DisableWeaponCollsion();

	void AttackEnd()override;

	UFUNCTION(BlueprintCallable)
	void LaunchProjectile(int32 projectileIndex);

	UPROPERTY(EditDefaultsOnly, Category = "Projectile")
	TArray<TSubclassOf<class AProjectile>> ProjectileClasses;

	UPROPERTY(EditDefaultsOnly, Category = "Projectile")
	int32	ProjectileIndex;

	UPROPERTY(BlueprintReadOnly)
	EEnemyState EnemyState = EEnemyState::EES_Patrolling;

	UPROPERTY(VisibleAnywhere, BlueprintReadWrite)
	UBoxComponent* WeaponHitBox;

	UPROPERTY(VisibleAnywhere, BlueprintReadWrite)
	UBoxComponent* WeaponHitBox2;

	UPROPERTY(VisibleAnywhere, BlueprintReadWrite)
	USceneComponent* TraceStart;

	UPROPERTY(VisibleAnywhere, BlueprintReadWrite)
	USceneComponent* TraceStart2;

	UPROPERTY(VisibleAnywhere, BlueprintReadWrite)
	USceneComponent* TraceEnd;

	UPROPERTY(VisibleAnywhere, BlueprintReadWrite)
	USceneComponent* TraceEnd2;

	UPROPERTY(VisibleAnywhere)
	UHealthBarComponent* HealthBarWidget;

	UPROPERTY(VisibleAnywhere)
	UPawnSensingComponent* PawnSensing;

	UPROPERTY()
	class AAIController* EnemyController;

	/*AI Area*/
	void CheckDeathDistance();
	void CheckPatrolTarget();
	void CheckCombatTarget();
	void PatrolTimerFinished();
	void HideHealthBar();
	void ShowHealthBar();
	void LoseInterest();
	void StartPatrolling();
	void ChaseTarget();
	bool OutCombatRadius();
	bool OutAttackRadius();
	bool InAttackRadius();
	bool InRangedAttackRadius();
	bool IsChasing();
	bool IsAlive();
	bool IsAttacking();
	bool IsEngaged();
	void ClearPatrolTimer();
	void ClearAttackTimer();
	void StartAttackTimer();

	UPROPERTY(EditDefaultsOnly)
	float DefaultDamageThreshold = 0.f;
	float CurrentDamageThreshold = 0.f;

private:

	UPROPERTY(EditInstanceOnly, Category = "AI Navigation")
	AActor* PatrolTarget;

	UPROPERTY(EditInstanceOnly, Category = "AI Navigation")
	TArray<AActor*> PatrolTargets;

	FTimerHandle PatrolTimer;

	FTimerHandle AttackTimer;

	UPROPERTY(EditAnywhere, Category = Combat)
	float AttackMin = 0.5f;

	UPROPERTY(EditAnywhere, Category = Combat)
	float AttackMax = 1.f;

	UPROPERTY(EditAnywhere, Category = Combat)
	float PatrollingSpeed = 125.f;

	UPROPERTY(EditAnywhere, Category = Combat)
	float ChasingSpeed = 300.f;

	UPROPERTY()
	double DeathDistance = -1.f;

	UPROPERTY(EditAnywhere, Category = "AI Navigation")
	double PatrolRadius = 200.f;

	UPROPERTY(EditAnywhere, Category = "AI Navigation")
	float PatrolWaitMin = 5.f;
	UPROPERTY(EditAnywhere, Category = "AI Navigation")
	float PatrolWaitMax = 10.f;

	UPROPERTY(EditAnywhere, Category = "AI Navigation")
	double CombatRadius = 1000.f;

	UPROPERTY(EditAnywhere, Category = "AI Navigation")
	double AttackRadius = 150.f;

	UPROPERTY(EditAnywhere, Category = "AI Navigation")
	double RangedAttackRadius = 500.f;

	UPROPERTY(EditAnywhere, Category = Combat)
	TSubclassOf<class ASoul> SoulClass;

	UPROPERTY(EditAnywhere, Category = Combat)
	TArray<TSubclassOf<class ASoul>> SoulClasses;

public:

	FORCEINLINE void ChangeChasingSpeed(float rate)  { ChasingSpeed *= rate; }

};
