// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/SaveGame.h"
#include "MySaveGame.generated.h"
class ASoul;
/**
 * 
 */
UCLASS()
class MYPROJECT_API UMySaveGame : public USaveGame
{
	GENERATED_BODY()
	
public:

	void SetObtainedSouls(const TArray<ASoul*>& ObtainedSouls);

	UPROPERTY(EditAnywhere,BlueprintReadWrite)
	FTransform PlayerLocation;
	UPROPERTY(EditAnywhere,BlueprintReadWrite)
	float MaxHealth;	  
	UPROPERTY(EditAnywhere,BlueprintReadWrite)
	float MaxStamina;	  
	UPROPERTY(EditAnywhere,BlueprintReadWrite)
	int32 GoldAmount;	  
	UPROPERTY(EditAnywhere,BlueprintReadWrite)
	int32 SoulAmount;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	int32 ObtainedRedSoulNum;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	int32 ObtainedGreenSoulNum;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SaveGame")
	TArray<ASoul*> ObtainedSouls;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SaveGame")
	TMap<int32, bool> ObtainedSoulsStates;

};
